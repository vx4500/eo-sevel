# Notice utilisateur — EO‑Suivi Élevage

Version de la notice : 2.2.35 — mise à jour le 25 août 2026.

Cette notice doit être relue à chaque livraison. Toute fonction ajoutée ou
modifiée doit être inscrite dans la section « Nouveautés de la version » avant
la publication, puis le numéro et la date ci-dessus doivent être actualisés.

## Nouveautés de la version 2.2.35

- Les bandes utilisent maintenant les listes officielles de sites/zones et de numéros de marquage.
- La structure distingue les capacités de porcs, de truies en maternité et de porcelets sous la mère, avec occupation et vannes visibles.
- La suppression d’un site, d’une salle ou d’une case vérifie toutes les données liées et affiche un refus explicite au lieu d’une erreur générale.
- Le tableau maternité comprend le sevrage par portée, le choix de la case/vanne de post-sevrage, le contrôle de capacité et la création du transfert d’effectif.
- Le tableau des effectifs par case indique la ou les bandes réellement présentes d’après les mouvements.

## Nouveautés de la version 2.2.34

- La fiche truie s'ouvre sur un résumé lisible (identification, dates clés et performances par portée) ; reproduction, historique, mesures, pertes, soins et sortie sont séparés en onglets.
- Les mesures ELD, poids et NEC ainsi que les informations générales de l'historique peuvent être corrigées directement.
- Une truie est reliée à sa case et à son numéro de vanne ; la mise-bas conserve cette liaison pour retrouver la portée même après un déplacement.
- La saisie rapide d'une perte demande le numéro de la truie, accepte une recherche par numéro, RFID, bande ou vanne et calcule l'âge depuis la mise-bas.
- Les actes du plan sanitaire ciblant les porcelets à partir de la mise-bas deviennent automatiquement des soins datés pour chaque portée, avec validation individuelle.
- Les motifs de sortie et de mortalité sont sélectionnés dans une liste commune adaptée à la reproduction, aux aplombs, à la mise-bas, à la santé et aux accidents.
- La liste des truies peut être imprimée selon les cases cochées ou selon une bande entière.
- Le nombre libre de doses d'IA est remplacé par trois cases matin, midi et soir ; la fiche propose ensuite l'IA probablement fécondante selon la durée de gestation observée.
- L'historique affiche explicitement le produit administré pour les traitements.

## Nouveautés de la version 2.2.33

- La page **Reproduction → Maternité / Mise-bas** ouvre automatiquement la bande actuellement dans sa période de mise-bas et permet aussi de choisir une autre bande.
- Toutes les truies du cycle sont regroupées et classées par état : à mettre bas, en cours, à surveiller ou terminée.
- Chaque fiche permet de démarrer puis de compléter la mise-bas sans perdre les nombres déjà saisis : heures, nés vifs, mort-nés, momifiés, pertes de naissance, délivrance et observations.
- Les pertes après la naissance sont ajoutées avec une cause configurée ; leur âge est calculé par le serveur et leur date est limitée de J0 à J+28.
- Les totaux de la bande indiquent les mises-bas restantes, les alertes, les nés vifs, les pertes et l'effectif estimé de porcelets présents.

## Nouveautés de la version 2.2.32

- Les factures d’aliment, vétérinaires, de semence et de génétique sans bande reçoivent automatiquement la bande la plus probable selon leur date, leur site lorsqu’il est connu et le calendrier des mises-bas.
- Chaque écran économique permet d’ajouter ou de retirer librement plusieurs bandes sur une facture.
- Lorsqu’une facture concerne plusieurs bandes, son montant et ses quantités sont répartis à parts égales : la facture n’est jamais comptée plusieurs fois.
- Une correction manuelle est conservée, y compris lorsque toutes les bandes ont volontairement été retirées.

## Nouveautés de la version 2.2.31

- Le contrôle de mise à jour compare maintenant la feuille de style réellement servie au fichier installé, sans exiger un numéro de version écrit dans le CSS.
- En cas de véritable échec, le script indique si la page de connexion, le numéro de version ou la feuille de style pose problème et affiche l’état et le journal du service avant le retour arrière.

## Mise-bas

1. Ouvrir la saisie rapide avec le bouton **+**, puis choisir **Mise-bas**.
2. Sans recherche, la liste contient seulement les truies dont la date prévue
   de mise-bas est comprise entre J-10 et J+10 et qui n'ont pas encore de
   mise-bas enregistrée pour cette bande.
3. Pour retrouver exceptionnellement une autre truie, saisir son numéro de
   travail, son RFID ou sa bande dans le champ de recherche manuelle.
4. Renseigner les nés vifs, mort-nés, momifiés et les autres observations.
5. Choisir **Délivrance OK** ou **Délivrance NOK**. Cocher **Suivi de mise-bas
   nécessaire** lorsque la truie doit rester sous surveillance.
6. Valider. Les informations sont visibles dans l'historique de la fiche truie.

Une mise-bas peut aussi être saisie directement depuis la fiche de la truie.
La recherche manuelle constitue une dérogation volontaire : vérifier le numéro
de la truie avant validation.

## Apports abattoir et effectifs des cases

À la création ou à l'import d'un apport abattoir, EO‑Suivi crée automatiquement
un mouvement de sortie lié à l'apport. Le logiciel retire d'abord les porcs des
cases où la présence de la bande est tracée. Si aucune case d'origine ne peut
être déterminée, il conserve une sortie avec la mention **case d'origine non
renseignée** afin que l'écart puisse être corrigé dans le registre des
mouvements.

Un nouvel import du même apport remplace ses mouvements automatiques : il ne
doit donc pas compter deux fois la sortie.

## Contrôles conseillés

- Après un apport, ouvrir les transferts et vérifier le numéro d'apport, la
  bande, la quantité et les cases d'origine.
- Contrôler régulièrement les alertes d'effectif négatif et les inventaires par
  case.
- Pour une délivrance NOK, consulter la fiche truie et traiter les lignes
  marquées **À suivre** selon le protocole de l'élevage.

## Nouveautés de la version 2.2.30

- Les duplicatas Cooperl sont reconnus même lorsque le mot « Apport » n'est pas présent dans le texte interne du PDF.
- Les apports de réformes et les documents composés de plusieurs pages sont analysés avec leur numéro, leur bon, leur frappe et leur montant HT.
- Les pages répétant le même bon sont regroupées ; les bons différents d'un même apport restent ventilables séparément.
- Les participations, pénalités et avoirs sans animaux modifient uniquement le résultat HT et ne créent aucune sortie de porcs.
- Un avoir conserve son numéro de document et le numéro de l'apport corrigé, sans écraser la vente initiale.

## Nouveautés de la version 2.2.29

- Au démarrage, les anciennes ventes récupèrent automatiquement le montant HT fiable conservé dans le détail de leurs lots.
- Les apports multi-lots sont affichés lot par lot avec leur référence, effectif, poids, TMP et montant HT.
- L'apport 226081270686 retrouve ainsi ses deux lots de 8 855,10 € et 9 607,76 €, soit 18 462,86 € HT.
- L'aperçu d'import permet d'affecter chaque ligne ou chaque lot à une bande différente avant une validation unique.
- Le menu Économie propose des vues séparées pour la génétique, l'aliment, le vétérinaire, la semence et les ventes abattoir.
- La page Imports regroupe le dépôt, l'historique, les documents à contrôler et l'accès direct à leur intégration.
- Un montant HT absent reste signalé comme manquant : le net ou le TTC n'est jamais utilisé silencieusement à sa place.

## Nouveautés de la version 2.2.26

- Le bouton « Bon de commande » de chaque commande client ouvre un document A4 prêt à imprimer.
- Le document présente l’élevage, le client, la session, la date de livraison, chaque produit, son unité, la quantité, le poids en kilogrammes, le prix unitaire et le montant de ligne.
- Le récapitulatif indique le poids total commandé, les autres unités et le montant total à régler.
- Des cases de préparation et des emplacements de signature ou règlement facilitent la remise au client.

## Nouveautés de la version 2.2.25

- Chaque bande présente le devenir des truies : verraterie, attente d’une nouvelle bande et réforme.
- Le flux des porcs reprend le nombre sevré, le nombre vendu et les dates des sorties enregistrées.
- Une bulle d’alertes accessible sur toutes les pages signale les relevés d’eau ou d’électricité attendus, les informations manquantes des bandes, les sevrages non remontés, les tâches en retard, les mises-bas à suivre et les effectifs incohérents.
- Un clic sur une alerte ouvre directement la page de traitement correspondante.

## Nouveautés de la version 2.2.24

- L’effectif actuel de chaque case est modifiable directement depuis la fiche de la bande.
- La section redondante « Derniers emplacements enregistrés » a été supprimée.
- Les chétifs, écrasés et porcelets tués par la truie saisis à la mise-bas apparaissent automatiquement dans les pertes de la truie.
- La cause d’une perte porcelet doit être choisie dans les causes configurées.
- Les résultats de recherche conduisent directement à la fiche de la truie, de la bande ou de la commande trouvée.

## Correctifs de la version 2.2.23

- Correction définitive de la page Commandes clients : son modèle HTML est maintenant embarqué et enregistré au démarrage.
- Compatibilité du journal avec les anciennes bases dont la colonne horodatage n’avait pas de valeur par défaut.

## Nouveautés de la version 2.2.22

- Page Commandes clients renforcée avec affichage de secours pour les anciennes bases incomplètes.
- Migration de compatibilité étendue à toutes les colonnes historiques des commandes et sessions de vente.
- Bandes affichées de la plus récente à la plus ancienne dans les listes principales.
- Module Vente directe activable ou désactivable depuis les paramètres.
- Présentation du profil et des modules plus lisible, avec libellés explicites.
- Informations de l’élevage nettoyées : les noms techniques des paramètres ne sont plus affichés.

## Nouveautés de la version 2.2.21

- Correction de la page Commandes clients pour les bases provenant d’anciennes versions.
- Bouton « Fin de vente » clôturant la session active et fermant les commandes publiques.
- Nouvelle page de bilan : commandes, quantités, kilogrammes, chiffre d’affaires, coûts, prix de revient total et au kg, marge.
- Suivi en direct des étapes de mise à jour GitHub, y compris pendant le redémarrage.
- Sauvegarde, restauration et mise à jour regroupées sur une seule page d’administration.

## Nouveautés de la version 2.2.20

- Gestion paramétrable des conduites en 3, 4, 5, 7, 10, 20 ou 21 bandes, avec intervalle ajustable.
- Date de mise-bas visible à côté du nom de bande et résultats pondérés arrondis à deux décimales.
- Jours de transition des plans d’alimentation modifiables directement dans le tableau.
- Causes de pertes de la saisie rapide synchronisées avec les paramètres.
- Assistant de résolution des problèmes progressif, organisé par stade et question par question.
- Images JPEG, PNG ou WebP importables pour les produits de la page de commande client.

## Nouveautés de la version 2.2.19

- Assistant de résolution des principaux problèmes sanitaires et techniques,
  avec questionnaire d'ambiance et signaux d'urgence.
- Calculateur de quantité à partir du poids, du nombre d'animaux, de la dose
  prescrite et de la concentration du produit.
- Lancement sécurisé d'une mise à jour GitHub depuis Administration → Mise à
  jour.
- Démonstration enrichie avec structure, pharmacie, tâches et causes de perte.
- Liste de mise-bas limitée à la période prévue, avec recherche manuelle.
- Suivi de mise-bas et état de délivrance OK/NOK.
- Mouvements automatiques de sortie lors des apports abattoir.
- Création de cette notice utilisateur versionnée.
- Écran unique pour préparer les cochettes, les truies vides et enregistrer
  toutes les inséminations cochées en une seule validation.
- Suppression de l'ancien écran Scanner.
- Transfert du calendrier ICS depuis Paramètres.
- Affichage conditionnel des charcutiers RFID et des prestataires.
- Centre unique « Importer un document ».
- Cahiers des charges et valorisations regroupés dans Économie.

## Règle de maintenance de la notice

Pour chaque mise à jour du logiciel :

1. modifier la version et la date en tête de fichier ;
2. ajouter les changements visibles par l'utilisateur dans « Nouveautés » ;
3. corriger les procédures concernées, pas seulement la liste des nouveautés ;
4. faire relire la notice pendant la revue de code ;
5. conserver dans Git la notice avec le code de la même version.


## Adoptions et nourrice artificielle (2.2.42)

Dans **Maternité / Mise-bas**, choisissez la bande, puis **Adoptions après mise-bas**.
Sélectionnez la truie donneuse, le nombre de porcelets vivants, la date et une destination :
une autre truie en allaitement ou une **case de nourrice artificielle**. La sortie et
l’arrivée sont enregistrées ensemble ; une destination vide ou un effectif insuffisant
empêche le transfert. Pour corriger le sens d'une adoption entre truies, saisissez un
transfert inverse à la date de correction.

Pour une machine à lait, créez une salle de type **Nourrice**, puis ses cases dans
**Salles, cases et vannes**. Une case de maternité peut également servir de destination.
Les cases n'imposent aucun plafond de porcelets sous la mère ou en nourrice ; leur nom
peut être modifié sur la ligne de la case.

La section **Nourrices artificielles** conserve chaque lot et sa bande d'origine.
Enregistrez ses décès avec une cause, ou sevrez tout ou partie du lot vers une case de
post-sevrage. Un sevrage crée automatiquement le mouvement et conserve le reliquat
dans la nourrice. Ne déclarez pas une seconde fois ces décès sous la truie donneuse.
Les dates doivent suivre l'entrée et les opérations déjà enregistrées.

Les **porcelets présents** comprennent les vivants sous les truies et dans les nourrices
rattachés à la bande affichée. Les **pertes enregistrées** incluent les décès déclarés en
nourrice, mais jamais les mort-nés ni les momifiés. Les sevrés quittent ce compteur.


## Gestion quotidienne et ergonomie (2.2.43)

- **Fiche truie → Modifier les mises-bas** : corrigez les nés vivants, mort-nés, momifiés et pertes à la naissance. Les pertes associées sont remplacées, pas cumulées. Une correction incompatible avec les adoptions, pertes ou sevrages enregistrés est refusée. La date reste protégée lorsqu’une adoption dépend de la portée.
- **Sélection des mères** : jusqu’à six critères simultanés. Renseignez les tétines fonctionnelles et le nombre de cas de splayleg observés dans la fiche truie ; une valeur vide signifie « inconnu », zéro signifie « aucun ». Les mères désignées restent visibles en vert.
- **Aide à la réforme** : quatre niveaux selon le nombre de critères dépassés, triés du plus prioritaire au moins prioritaire. La réforme reste une décision manuelle.
- **Inséminations** : importez d’abord la facture de semence dans Imports, puis choisissez la facture, la saisie manuelle ou le mode automatique. L’automatique retient la dernière facture antérieure ou égale à la date d’IA, liée à la bande. Sans bande, il utilise la dernière facture disponible.
- **Notes quotidiennes** : l’historique permet de modifier et supprimer chaque note.
- **Tâches et entretien** : création, modification, suppression et achèvement des travaux ponctuels, entretiens périodiques et dates de lavage sur une page.
- **Eau/énergie** : attribuez le bon site au compteur. Chaque relevé permet de modifier la liste des bandes ou de la recalculer. Le calcul automatique reste une estimation à partir des dates de bande et n’inclut plus les autres sites. Sans site défini, aucune bande n’est déduite. Les anciens relevés ne sont pas réécrits sans votre action.
- **Stocks → Faire l’inventaire** : exportez le CSV, remplissez uniquement `quantite_comptee`, puis réimportez. Cellule vide : aucun changement ; zéro : stock nul. Produits de pharmacie et niveaux des silos sont inclus. Les noms, unités, identifiants et stocks de référence doivent rester intacts. Si un stock a changé depuis l’export, l’import entier est refusé : réexportez. Chaque correction produit un mouvement ou un relevé traçable.
- Les bandes portant exactement le marqueur d’import automatique v1.14 sont nettoyées au démarrage. Les lignes touchées sont archivées dans `archive_nettoyage` avant modification. Les événements à lien facultatif sont conservés sans bande fantôme. Une bande encore liée à des adoptions est conservée et signalée dans les journaux afin de ne pas détacher des porcelets de leur historique. Faites une sauvegarde avant mise à jour.
