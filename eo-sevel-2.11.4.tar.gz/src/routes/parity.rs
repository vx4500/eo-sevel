use super::*;
use std::path::{Path as FsPath, PathBuf};

fn require_admin(session: &SessionData) -> AppResult<()> {
    if session.est_admin() {
        Ok(())
    } else {
        Err(AppError::Forbidden)
    }
}

async fn sow_band(pool: &SqlitePool, sow_id: i64) -> AppResult<Option<i64>> {
    Ok(sqlx::query_scalar(
        "SELECT b.id FROM truie t JOIN bande b ON b.code=t.bande_code WHERE t.id=? ORDER BY b.active DESC,b.id DESC LIMIT 1",
    )
    .bind(sow_id)
    .fetch_optional(pool)
    .await?)
}

fn required_date(form: &HashMap<String, String>) -> AppResult<String> {
    form_date(form, "date")?
        .ok_or_else(|| AppError::Invalid("Date obligatoire (AAAA-MM-JJ)".into()))
}

async fn add_sow_event(
    state: &AppState,
    session: &SessionData,
    sow_id: i64,
    kind: &str,
    form: &HashMap<String, String>,
) -> AppResult<Response> {
    require_writer(session)?;
    verify_csrf(session, form)?;
    let date = required_date(form)?;
    let band_id = sow_band(&state.pool, sow_id).await?;
    let exists: i64 = sqlx::query_scalar("SELECT COUNT(*) FROM truie WHERE id=?")
        .bind(sow_id)
        .fetch_one(&state.pool)
        .await?;
    if exists == 0 {
        return Err(AppError::NotFound);
    }
    let slots = ia_slots(form);
    let slot_text = (!slots.is_empty()).then(|| slots.join(","));
    let dose_count = if kind == "ia" {
        Some(slots.len().max(1) as i64)
    } else {
        form_i64(form, "nb_doses")
    };
    sqlx::query("INSERT INTO evenement(type,date,truie_id,bande_id,verrat_id,produit,motif,delai_attente,resultat,nb_doses,creneaux_ia,note,suivi_actif) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,0)")
        .bind(kind).bind(date).bind(sow_id).bind(band_id)
        .bind(form_i64(form,"verrat_id")).bind(form_text(form,"produit"))
        .bind(form_text(form,"motif")).bind(form_i64(form,"delai_attente"))
        .bind(form_text(form,"resultat")).bind(dose_count).bind(slot_text)
        .bind(form_text(form,"note")).execute(&state.pool).await?;
    db::journal(
        &state.pool,
        &session.nom,
        "ajouter",
        kind,
        &format!("truie={sow_id}"),
        &format!("/truie/{sow_id}/{kind}"),
    )
    .await;
    Ok(Redirect::to(&format!("/truie/{sow_id}")).into_response())
}

pub(super) async fn truie_chaleur(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
    Path(id): Path<i64>,
    Form(mut form): Form<HashMap<String, String>>,
) -> AppResult<Response> {
    let mut observations = Vec::new();
    for (key, label) in [
        ("chaleur_vulve", "aspect de la vulve"),
        ("chaleur_comportement", "comportement"),
        ("chaleur_immobilite", "réflexe d’immobilité"),
    ] {
        if form.contains_key(key) {
            observations.push(label);
        }
    }
    if !observations.is_empty() {
        let suffix = form_text(&form, "note")
            .map(|v| format!(" — {v}"))
            .unwrap_or_default();
        form.insert(
            "note".into(),
            format!("{}{suffix}", observations.join(", ")),
        );
    }
    add_sow_event(&state, &session, id, "chaleur", &form).await
}
pub(super) async fn truie_ia(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
    Path(id): Path<i64>,
    Form(form): Form<HashMap<String, String>>,
) -> AppResult<Response> {
    add_sow_event(&state, &session, id, "ia", &form).await
}
pub(super) async fn truie_echo(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
    Path(id): Path<i64>,
    Form(form): Form<HashMap<String, String>>,
) -> AppResult<Response> {
    add_sow_event(&state, &session, id, "echo", &form).await
}
pub(super) async fn truie_traitement(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
    Path(id): Path<i64>,
    Form(form): Form<HashMap<String, String>>,
) -> AppResult<Response> {
    if form_text(&form, "produit").is_none() {
        return Err(AppError::Invalid("Produit obligatoire".into()));
    }
    add_sow_event(&state, &session, id, "traitement", &form).await
}

pub(super) async fn truie_mise_bas(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
    Path(id): Path<i64>,
    Form(form): Form<HashMap<String, String>>,
) -> AppResult<Response> {
    require_writer(&session)?;
    verify_csrf(&session, &form)?;
    let date = required_date(&form)?;
    let band_id = form_i64(&form, "bande_id").or(sow_band(&state.pool, id).await?);
    let case_id: Option<i64> = sqlx::query_scalar("SELECT case_id FROM truie WHERE id=?")
        .bind(id)
        .fetch_optional(&state.pool)
        .await?
        .flatten();
    let live = form_i64(&form, "nes_vifs").unwrap_or(0).max(0);
    let still = form_i64(&form, "mort_nes").unwrap_or(0).max(0);
    let mummies = form_i64(&form, "momifies").unwrap_or(0).max(0);
    let weak = form_i64(&form, "chetifs").unwrap_or(0).max(0);
    let crushed = form_i64(&form, "ecrases").unwrap_or(0).max(0);
    let killed = form_i64(&form, "tues_truie").unwrap_or(0).max(0);
    let total = live + still + mummies;
    let existing:Option<i64>=sqlx::query_scalar("SELECT id FROM evenement WHERE truie_id=? AND type='mise_bas' AND bande_id IS ? ORDER BY id DESC LIMIT 1")
        .bind(id).bind(band_id).fetch_optional(&state.pool).await?;
    let mut tx = state.pool.begin().await?;
    let event_id = if let Some(event_id) = existing {
        sqlx::query("UPDATE evenement SET date=?,nes_totaux=?,nes_vifs=?,mort_nes=?,momifies=?,chetifs=?,ecrases=?,tues_truie=?,heure_debut=?,heure_fin=?,suivi_actif=?,delivrance_ok=?,note=?,case_id=COALESCE(case_id,?) WHERE id=?")
            .bind(&date).bind(total).bind(live).bind(still).bind(mummies).bind(weak)
            .bind(crushed).bind(killed).bind(form_text(&form,"heure_debut"))
            .bind(form_text(&form,"heure_fin")).bind(form.contains_key("suivi_actif") as i64).bind(form_i64(&form,"delivrance_ok")).bind(form_text(&form,"note")).bind(case_id).bind(event_id).execute(&mut *tx).await?;
        event_id
    } else {
        let result = sqlx::query("INSERT INTO evenement(type,date,truie_id,bande_id,nes_totaux,nes_vifs,mort_nes,momifies,chetifs,ecrases,tues_truie,heure_debut,heure_fin,suivi_actif,delivrance_ok,note,case_id) VALUES('mise_bas',?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
            .bind(&date).bind(id).bind(band_id).bind(total).bind(live).bind(still).bind(mummies).bind(weak)
            .bind(crushed).bind(killed).bind(form_text(&form,"heure_debut"))
            .bind(form_text(&form,"heure_fin")).bind(form.contains_key("suivi_actif") as i64).bind(form_i64(&form,"delivrance_ok")).bind(form_text(&form,"note")).bind(case_id).execute(&mut *tx).await?;
        if parse_stored_date(&date).is_some_and(|d| d <= Local::now().date_naive()) {
            sqlx::query("UPDATE truie SET rang=rang+1,updated_at=CURRENT_TIMESTAMP WHERE id=?")
                .bind(id)
                .execute(&mut *tx)
                .await?;
        }
        result.last_insert_rowid()
    };
    if let Some(band_id) = band_id {
        sqlx::query("UPDATE truie SET bande_code=(SELECT code FROM bande WHERE id=?),perf_nt=?,perf_nv=?,perf_mn=?,perf_mo=?,updated_at=CURRENT_TIMESTAMP WHERE id=?")
            .bind(band_id).bind(total as f64).bind(live as f64).bind(still as f64).bind(mummies as f64).bind(id).execute(&mut *tx).await?;
    }
    tx.commit().await?;
    synchroniser_pertes_mise_bas(
        &state.pool,
        event_id,
        id,
        band_id,
        &date,
        (weak, crushed, killed),
    )
    .await?;
    synchroniser_soins_portee(&state.pool, event_id, id, band_id, &date).await?;
    let fallback = format!("/truie/{id}");
    let destination = form_text(&form, "retour")
        .filter(|value| value.starts_with("/maternite") && !value.starts_with("//"))
        .unwrap_or(fallback);
    Ok(Redirect::to(&destination).into_response())
}

pub(super) async fn truie_sevrage(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
    Path(id): Path<i64>,
    Form(form): Form<HashMap<String, String>>,
) -> AppResult<Response> {
    require_writer(&session)?;
    verify_csrf(&session, &form)?;
    let date = required_date(&form)?;
    let band_id = form_i64(&form, "bande_id").or(sow_band(&state.pool, id).await?);
    let weaned = form_i64(&form, "nb_sevres").unwrap_or(0).max(0);
    let adopted = form_i64(&form, "adoptes").unwrap_or(0).max(0);
    let removed = form_i64(&form, "retires").unwrap_or(0).max(0);
    let existing:Option<i64>=sqlx::query_scalar("SELECT id FROM evenement WHERE truie_id=? AND type='sevrage' AND bande_id IS ? ORDER BY id DESC LIMIT 1").bind(id).bind(band_id).fetch_optional(&state.pool).await?;
    let mut tx = state.pool.begin().await?;
    if let Some(event_id) = existing {
        sqlx::query("UPDATE evenement SET date=?,nb_sevres=?,poids_moyen=?,adoptes=?,retires=?,eld_entree=?,eld_sortie=?,note=? WHERE id=?")
            .bind(&date).bind(weaned).bind(form_f64(&form,"poids_moyen")).bind(adopted).bind(removed).bind(form_f64(&form,"eld_entree")).bind(form_f64(&form,"eld_sortie")).bind(form_text(&form,"note")).bind(event_id).execute(&mut *tx).await?;
    } else {
        sqlx::query("INSERT INTO evenement(type,date,truie_id,bande_id,nb_sevres,poids_moyen,adoptes,retires,eld_entree,eld_sortie,note) VALUES('sevrage',?,?,?,?,?,?,?,?,?,?)")
            .bind(&date).bind(id).bind(band_id).bind(weaned).bind(form_f64(&form,"poids_moyen")).bind(adopted).bind(removed).bind(form_f64(&form,"eld_entree")).bind(form_f64(&form,"eld_sortie")).bind(form_text(&form,"note")).execute(&mut *tx).await?;
    }
    sqlx::query("UPDATE truie SET perf_sevres=?,perf_adoptes=?,perf_retires=?,bande_code=CASE WHEN date(?)<=date('now') AND bande_code=(SELECT code FROM bande WHERE id=?) THEN NULL ELSE bande_code END,updated_at=CURRENT_TIMESTAMP WHERE id=?")
        .bind(weaned as f64).bind(adopted as f64).bind(removed as f64).bind(&date).bind(band_id).bind(id).execute(&mut *tx).await?;
    tx.commit().await?;
    Ok(Redirect::to(&format!("/truie/{id}")).into_response())
}

pub(super) async fn portee_bande_truie(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
    Path((band_id, sow_id)): Path<(i64, i64)>,
    Form(form): Form<HashMap<String, String>>,
) -> AppResult<Response> {
    require_writer(&session)?;
    verify_csrf(&session, &form)?;
    let band: String = sqlx::query_scalar("SELECT code FROM bande WHERE id=?")
        .bind(band_id)
        .fetch_optional(&state.pool)
        .await?
        .ok_or(AppError::NotFound)?;
    let sow: String = sqlx::query_scalar("SELECT num_travail FROM truie WHERE id=?")
        .bind(sow_id)
        .fetch_optional(&state.pool)
        .await?
        .ok_or(AppError::NotFound)?;
    let live = form_f64(&form, "nes_vifs").or_else(|| form_f64(&form, "nv"));
    let adopted = form_f64(&form, "adoptes")
        .or_else(|| form_f64(&form, "ad"))
        .unwrap_or(0.0);
    let removed = form_f64(&form, "retires")
        .or_else(|| form_f64(&form, "re"))
        .unwrap_or(0.0);
    let weaned = form_f64(&form, "nb_sevres").or_else(|| form_f64(&form, "sev"));
    let loss_rate = match (live, weaned) {
        (Some(nv), Some(sev)) if nv + adopted > 0.0 => {
            Some(((nv + adopted - removed - sev).max(0.0) / (nv + adopted)) * 100.0)
        }
        _ => None,
    };
    let mut tx = state.pool.begin().await?;
    sqlx::query("UPDATE truie SET perf_adoptes=?,perf_retires=?,perf_sevres=?,perf_tx_perte=?,updated_at=CURRENT_TIMESTAMP WHERE id=?").bind(adopted).bind(removed).bind(weaned).bind(loss_rate).bind(sow_id).execute(&mut *tx).await?;
    sqlx::query("UPDATE porteerang SET ad=?,re=?,sev=?,tx_pertes=? WHERE id=(SELECT id FROM porteerang WHERE num_travail=? AND bande=? ORDER BY rang DESC,id DESC LIMIT 1)")
        .bind(adopted).bind(removed).bind(weaned).bind(loss_rate).bind(sow).bind(&band).execute(&mut *tx).await?;
    tx.commit().await?;
    Ok(Redirect::to(&format!("/bande/{band_id}")).into_response())
}

pub(super) async fn truie_sortie(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
    Path(id): Path<i64>,
    Form(form): Form<HashMap<String, String>>,
) -> AppResult<Response> {
    require_writer(&session)?;
    verify_csrf(&session, &form)?;
    let date = required_date(&form)?;
    let reason = form_text(&form, "motif_sortie")
        .or_else(|| form_text(&form, "motif"))
        .ok_or_else(|| AppError::Invalid("Motif obligatoire".into()))?;
    if !SOW_EXIT_REASONS.contains(&reason.as_str()) {
        return Err(AppError::Invalid(
            "Sélectionnez un motif de sortie proposé".into(),
        ));
    }
    sqlx::query("UPDATE truie SET reformee=1,statut='sortie',date_reforme=?,motif_sortie=?,prix_sortie=?,num_apport_sortie=?,updated_at=CURRENT_TIMESTAMP WHERE id=?")
        .bind(date).bind(reason).bind(form_f64(&form,"prix_sortie")).bind(form_text(&form,"num_apport_sortie")).bind(id).execute(&state.pool).await?;
    Ok(Redirect::to(&format!("/truie/{id}")).into_response())
}

pub(super) async fn truie_reclasser_verrat(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
    Path(id): Path<i64>,
    Form(form): Form<HashMap<String, String>>,
) -> AppResult<Response> {
    require_writer(&session)?;
    verify_csrf(&session, &form)?;
    let row: Option<(String, Option<String>, Option<String>)> =
        sqlx::query_as("SELECT num_travail,race,note FROM truie WHERE id=? AND reformee=0")
            .bind(id)
            .fetch_optional(&state.pool)
            .await?;
    let Some((code, race, note)) = row else {
        return Err(AppError::NotFound);
    };
    let mut tx = state.pool.begin().await?;
    sqlx::query("INSERT INTO verrat(code,race,note,actif) SELECT ?,?,?,1 WHERE NOT EXISTS(SELECT 1 FROM verrat WHERE lower(code)=lower(?))").bind(&code).bind(race).bind(note).bind(&code).execute(&mut *tx).await?;
    sqlx::query("UPDATE truie SET reformee=1,statut='reclasse_verrat',date_reforme=?,motif_sortie='Reclassé verrat',updated_at=CURRENT_TIMESTAMP WHERE id=?").bind(form_date(&form,"date")?).bind(id).execute(&mut *tx).await?;
    tx.commit().await?;
    Ok(Redirect::to("/truies").into_response())
}

#[allow(dead_code)]
pub(super) async fn attente(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
) -> AppResult<Html<String>> {
    let capacite: i64 = sqlx::query_scalar(
        "SELECT COALESCE((SELECT valeur FROM reglage WHERE cle='capacite_verraterie'),0)",
    )
    .fetch_one(&state.pool)
    .await?;
    let occupation:i64=sqlx::query_scalar("SELECT COUNT(*) FROM truie t LEFT JOIN casesalle c ON c.id=t.case_id LEFT JOIN salle s ON s.id=COALESCE(t.salle_id,c.salle_id) WHERE t.reformee=0 AND (lower(COALESCE(s.type,'')) LIKE '%verrater%' OR lower(COALESCE(s.nom,'')) LIKE '%verrater%')").fetch_one(&state.pool).await?;
    let rows=generic_rows(&state.pool,r#"
        SELECT t.id,t.num_travail,t.num_national,t.rfid,t.race,t.date_entree,t.rang,
          CASE
            WHEN t.rang=0 THEN 'Cochette'
            WHEN (SELECT e.type FROM evenement e WHERE e.truie_id=t.id ORDER BY e.date DESC,e.id DESC LIMIT 1)='sevrage' THEN 'Sortie maternité'
            WHEN lower(COALESCE((SELECT e.resultat FROM evenement e WHERE e.truie_id=t.id AND e.type='echo' ORDER BY e.date DESC,e.id DESC LIMIT 1),'')) IN ('vide','négative','negative','negatif','négatif') THEN 'Retour IA'
            ELSE 'Sans bande'
          END AS categorie,
          (SELECT e.type FROM evenement e WHERE e.truie_id=t.id ORDER BY e.date DESC,e.id DESC LIMIT 1) AS dernier_evenement,
          (SELECT e.date FROM evenement e WHERE e.truie_id=t.id ORDER BY e.date DESC,e.id DESC LIMIT 1) AS derniere_date,
          (SELECT e.date FROM evenement e WHERE e.truie_id=t.id AND e.type='sevrage' ORDER BY e.date DESC,e.id DESC LIMIT 1) AS dernier_sevrage,
          date((SELECT e.date FROM evenement e WHERE e.truie_id=t.id AND e.type='sevrage' ORDER BY e.date DESC,e.id DESC LIMIT 1),printf('+%d day',COALESCE((SELECT valeur FROM reglage WHERE cle='chaleur_post_sevrage_j'),5))) AS chaleur_prevue,
          COALESCE(si.nom,si.code) AS batiment,s.nom AS salle,c.nom AS case_nom
        FROM truie t
        LEFT JOIN casesalle c ON c.id=t.case_id
        LEFT JOIN salle s ON s.id=COALESCE(t.salle_id,c.salle_id)
        LEFT JOIN site si ON si.id=s.site_id
        WHERE t.reformee=0
          AND NOT EXISTS(SELECT 1 FROM bande b WHERE b.active=1 AND b.code=t.bande_code)
        ORDER BY CASE WHEN chaleur_prevue IS NULL THEN 1 ELSE 0 END,chaleur_prevue,t.num_travail
    "#).await?;
    let bands = sqlx::query_as::<_, Bande>(BAND_SELECT_ACTIVE)
        .fetch_all(&state.pool)
        .await?;
    let places_disponibles = places_disponibles(capacite, occupation);
    let attente = rows.len() as i64;
    let mut ctx = context(&session);
    ctx.insert("truies".into(), Value::Array(rows));
    ctx.insert(
        "bandes".into(),
        serde_json::to_value(bands).unwrap_or_default(),
    );
    ctx.insert("capacite".into(), json!(capacite));
    ctx.insert("occupation".into(), json!(occupation));
    ctx.insert("places_disponibles".into(), json!(places_disponibles));
    ctx.insert("attente".into(), json!(attente));
    ctx.insert("saturee".into(), json!(occupation >= capacite));
    ctx.insert(
        "depasse_capacite".into(),
        json!(attente > places_disponibles),
    );
    render(&state, "attente.html", Value::Object(ctx))
}

pub(super) async fn cause_ajouter(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
    Form(form): Form<HashMap<String, String>>,
) -> AppResult<Response> {
    require_writer(&session)?;
    verify_csrf(&session, &form)?;
    let label = form_text(&form, "libelle")
        .ok_or_else(|| AppError::Invalid("Libellé obligatoire".into()))?;
    sqlx::query("INSERT INTO causeperte(libelle) SELECT ? WHERE NOT EXISTS(SELECT 1 FROM causeperte WHERE lower(libelle)=lower(?))").bind(&label).bind(&label).execute(&state.pool).await?;
    Ok(Redirect::to("/parametres#causes").into_response())
}
pub(super) async fn cause_supprimer(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
    Path(id): Path<i64>,
    Form(form): Form<HashMap<String, String>>,
) -> AppResult<Response> {
    require_writer(&session)?;
    verify_csrf(&session, &form)?;
    sqlx::query("DELETE FROM causeperte WHERE id=?")
        .bind(id)
        .execute(&state.pool)
        .await?;
    Ok(Redirect::to("/parametres#causes").into_response())
}

pub(super) async fn bande_engraisseur(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
    Path(id): Path<i64>,
    Form(form): Form<HashMap<String, String>>,
) -> AppResult<Response> {
    require_writer(&session)?;
    verify_csrf(&session, &form)?;
    sqlx::query("UPDATE bande SET engraisseur_id=?,poids_cible=?,instructions=?,updated_at=CURRENT_TIMESTAMP WHERE id=?").bind(form_i64(&form,"engraisseur_id")).bind(form_f64(&form,"poids_cible")).bind(form_text(&form,"instructions")).bind(id).execute(&state.pool).await?;
    Ok(Redirect::to(&format!("/bande/{id}")).into_response())
}

pub(super) async fn bande_inventaire(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
    Path(id): Path<i64>,
    Form(form): Form<HashMap<String, String>>,
) -> AppResult<Response> {
    require_writer(&session)?;
    verify_csrf(&session, &form)?;
    let number = form_i64(&form, "nombre")
        .filter(|v| *v >= 0)
        .ok_or_else(|| AppError::Invalid("Effectif invalide".into()))?;
    let date =
        form_date(&form, "date")?.ok_or_else(|| AppError::Invalid("Date obligatoire".into()))?;
    let code: String = sqlx::query_scalar("SELECT code FROM bande WHERE id=?")
        .bind(id)
        .fetch_optional(&state.pool)
        .await?
        .ok_or(AppError::NotFound)?;
    sqlx::query("INSERT INTO mouvementstock(date,bande_code,nombre,poids,libelle,type_saisie,est_stock) VALUES(?,?,?,?,?,'inventaire',1)").bind(date).bind(code).bind(number).bind(form_f64(&form,"poids")).bind(form_text(&form,"note").unwrap_or_else(||"Inventaire physique".into())).execute(&state.pool).await?;
    Ok(Redirect::to(&format!("/bande/{id}")).into_response())
}

pub(super) async fn mortalite_supprimer(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
    Path((id, declaration_id)): Path<(i64, i64)>,
    Form(form): Form<HashMap<String, String>>,
) -> AppResult<Response> {
    require_writer(&session)?;
    verify_csrf(&session, &form)?;
    sqlx::query(
        "DELETE FROM declarationmort WHERE id=? AND bande_code=(SELECT code FROM bande WHERE id=?)",
    )
    .bind(declaration_id)
    .bind(id)
    .execute(&state.pool)
    .await?;
    Ok(Redirect::to(&format!("/bande/{id}#mortalite")).into_response())
}

pub(super) async fn bande_transfert_porcs(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
    Path(id): Path<i64>,
    Form(mut form): Form<HashMap<String, String>>,
) -> AppResult<Response> {
    form.insert("source".into(), format!("bande:{id}"));
    super::transferts_porcs(State(state), Extension(session), Form(form)).await
}

fn selected_bands(form: &HashMap<String, String>) -> Option<String> {
    let mut ids = form_selected_ids(form, "bande_");
    if let Some(raw) = form_text(form, "bandes") {
        ids.extend(raw.split(',').filter_map(|v| v.trim().parse::<i64>().ok()));
    }
    ids.sort_unstable();
    ids.dedup();
    if ids.is_empty() {
        None
    } else {
        Some(
            ids.iter()
                .map(ToString::to_string)
                .collect::<Vec<_>>()
                .join(","),
        )
    }
}

pub(super) async fn economique_facture_affectations(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
    Path((category, id)): Path<(String, i64)>,
    Form(form): Form<HashMap<String, String>>,
) -> AppResult<Response> {
    require_writer(&session)?;
    verify_csrf(&session, &form)?;
    let (table, redirect) = match category.as_str() {
        "aliment" => ("livraisonaliment", "aliment"),
        "veto" => ("achatveto", "veterinaire"),
        "semence" => ("achatsemence", "semence"),
        "genetique" => ("achatgenetique", "genetique"),
        _ => return Err(AppError::NotFound),
    };
    let exists: i64 = sqlx::query_scalar(&format!("SELECT COUNT(*) FROM {table} WHERE id=?"))
        .bind(id)
        .fetch_one(&state.pool)
        .await?;
    if exists == 0 {
        return Err(AppError::NotFound);
    }
    let ids = selected_bands(&form)
        .unwrap_or_default()
        .split(',')
        .filter_map(|value| value.parse::<i64>().ok())
        .collect::<Vec<_>>();
    let mut tx = state.pool.begin().await?;
    sqlx::query("DELETE FROM affectationfacturebande WHERE categorie=? AND facture_id=?")
        .bind(&category)
        .bind(id)
        .execute(&mut *tx)
        .await?;
    let mut valid_ids = Vec::new();
    for band_id in &ids {
        let inserted = sqlx::query("INSERT INTO affectationfacturebande(categorie,facture_id,bande_id,automatique) SELECT ?,?,?,0 WHERE EXISTS(SELECT 1 FROM bande WHERE id=?)")
            .bind(&category).bind(id).bind(band_id).bind(band_id).execute(&mut *tx).await?;
        if inserted.rows_affected() == 1 {
            valid_ids.push(*band_id);
        }
    }
    sqlx::query("INSERT INTO affectationfacturecontrole(categorie,facture_id,verrou_manuel,modifie_le) VALUES(?,?,1,CURRENT_TIMESTAMP) ON CONFLICT(categorie,facture_id) DO UPDATE SET verrou_manuel=1,modifie_le=CURRENT_TIMESTAMP")
        .bind(&category).bind(id).execute(&mut *tx).await?;
    let primary = valid_ids.first().copied();
    let selected = (!valid_ids.is_empty()).then(|| {
        valid_ids
            .iter()
            .map(ToString::to_string)
            .collect::<Vec<_>>()
            .join(",")
    });
    match category.as_str() {
        "aliment" => {
            sqlx::query("UPDATE livraisonaliment SET bande_id=?,bandes=? WHERE id=?")
                .bind(primary)
                .bind(&selected)
                .bind(id)
                .execute(&mut *tx)
                .await?;
        }
        "veto" => {
            sqlx::query("UPDATE achatveto SET bande_id=?,bandes=? WHERE id=?")
                .bind(primary)
                .bind(&selected)
                .bind(id)
                .execute(&mut *tx)
                .await?;
        }
        "semence" => {
            sqlx::query("UPDATE achatsemence SET bande_id=? WHERE id=?")
                .bind(primary)
                .bind(id)
                .execute(&mut *tx)
                .await?;
        }
        "genetique" => {
            sqlx::query("UPDATE achatgenetique SET bande_code=(SELECT code FROM bande WHERE id=?),toutes_bandes=? WHERE id=?")
                .bind(primary).bind(form.contains_key("toutes_bandes")).bind(id).execute(&mut *tx).await?;
        }
        _ => unreachable!(),
    }
    tx.commit().await?;
    if category == "genetique" {
        crate::affectation::boars(&state.pool)
            .await
            .map_err(AppError::Internal)?;
    }
    Ok(Redirect::to(&format!(
        "/economique?secteur={redirect}#facture-{category}-{id}"
    ))
    .into_response())
}

macro_rules! economy_simple_update {
    ($name:ident,$table:literal,$column:literal,$parser:expr,$redirect:literal) => {
        pub(super) async fn $name(
            State(state): State<AppState>,
            Extension(session): Extension<SessionData>,
            Path(id): Path<i64>,
            Form(form): Form<HashMap<String, String>>,
        ) -> AppResult<Response> {
            require_writer(&session)?;
            verify_csrf(&session, &form)?;
            let value = $parser(&form);
            let sql = format!("UPDATE {} SET {}=? WHERE id=?", $table, $column);
            sqlx::query(&sql)
                .bind(value)
                .bind(id)
                .execute(&state.pool)
                .await?;
            Ok(Redirect::to($redirect).into_response())
        }
    };
}
economy_simple_update!(
    economique_aliment_site,
    "livraisonaliment",
    "site",
    |f: &HashMap<String, String>| form_text(f, "site"),
    "/economique"
);
economy_simple_update!(
    economique_veto_site,
    "achatveto",
    "site",
    |f: &HashMap<String, String>| form_text(f, "site"),
    "/economique"
);
economy_simple_update!(
    economique_genetique_bande,
    "achatgenetique",
    "bande_code",
    |f: &HashMap<String, String>| form_text(f, "bande_code"),
    "/economique"
);
economy_simple_update!(
    economique_semence_bande,
    "achatsemence",
    "bande_id",
    |f: &HashMap<String, String>| form_i64(f, "bande_id"),
    "/economique"
);

economy_simple_update!(
    economique_veto_bande,
    "achatveto",
    "bande_id",
    |f: &HashMap<String, String>| form_i64(f, "bande_id"),
    "/economique"
);

pub(super) async fn economique_aliment_bandes(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
    Path(id): Path<i64>,
    Form(form): Form<HashMap<String, String>>,
) -> AppResult<Response> {
    require_writer(&session)?;
    verify_csrf(&session, &form)?;
    sqlx::query("UPDATE livraisonaliment SET bandes=?,bande_id=NULL WHERE id=?")
        .bind(selected_bands(&form))
        .bind(id)
        .execute(&state.pool)
        .await?;
    Ok(Redirect::to("/economique").into_response())
}
pub(super) async fn economique_veto_bandes(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
    Path(id): Path<i64>,
    Form(form): Form<HashMap<String, String>>,
) -> AppResult<Response> {
    require_writer(&session)?;
    verify_csrf(&session, &form)?;
    sqlx::query("UPDATE achatveto SET bandes=?,bande_id=NULL WHERE id=?")
        .bind(selected_bands(&form))
        .bind(id)
        .execute(&state.pool)
        .await?;
    Ok(Redirect::to("/economique").into_response())
}
pub(super) async fn economique_semence_montant(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
    Path(id): Path<i64>,
    Form(form): Form<HashMap<String, String>>,
) -> AppResult<Response> {
    require_writer(&session)?;
    verify_csrf(&session, &form)?;
    let amount = form_f64(&form, "montant_ht")
        .filter(|v| *v >= 0.0)
        .ok_or_else(|| AppError::Invalid("Montant invalide".into()))?;
    sqlx::query("UPDATE achatsemence SET montant_ht=?,montant_ttc=? WHERE id=?")
        .bind(amount)
        .bind(form_f64(&form, "montant_ttc"))
        .bind(id)
        .execute(&state.pool)
        .await?;
    Ok(Redirect::to("/economique").into_response())
}

async fn auto_link_economy(pool: &SqlitePool, include_sales: bool) -> AppResult<u64> {
    let mut changed = db::auto_assign_economic_invoices(pool).await?;
    if include_sales {
        changed += super::ventes::auto_assign(pool).await?;
    }
    Ok(changed)
}
pub(super) async fn economique_auto_lier(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
    Form(form): Form<HashMap<String, String>>,
) -> AppResult<Response> {
    require_writer(&session)?;
    verify_csrf(&session, &form)?;
    let changed = auto_link_economy(&state.pool, true).await?;
    Ok(Redirect::to(&format!("/economique?liaisons={changed}")).into_response())
}
pub(super) async fn economique_rattacher_auto(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
    Form(form): Form<HashMap<String, String>>,
) -> AppResult<Response> {
    require_writer(&session)?;
    verify_csrf(&session, &form)?;
    let changed = auto_link_economy(&state.pool, true).await?;
    Ok(Redirect::to(&format!("/economique?liaisons={changed}")).into_response())
}

fn ascii_pdf(lines: &[String]) -> Vec<u8> {
    fn clean(value: &str) -> String {
        value
            .chars()
            .map(|c| match c {
                '(' | '\\' | ')' => ' ',
                c if c.is_ascii() => c,
                _ => ' ',
            })
            .collect()
    }
    let mut content = String::from("BT /F1 11 Tf 50 790 Td 14 TL ");
    for line in lines.iter().take(52) {
        content.push_str(&format!("({}) Tj T* ", clean(line)));
    }
    content.push_str("ET");
    let objects=[
        "<< /Type /Catalog /Pages 2 0 R >>".to_string(),
        "<< /Type /Pages /Kids [3 0 R] /Count 1 >>".to_string(),
        "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 5 0 R >> >> /Contents 4 0 R >>".to_string(),
        format!("<< /Length {} >>\nstream\n{}\nendstream",content.len(),content),
        "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>".to_string(),
    ];
    let mut pdf = b"%PDF-1.4\n".to_vec();
    let mut offsets = Vec::new();
    for (index, obj) in objects.iter().enumerate() {
        offsets.push(pdf.len());
        pdf.extend_from_slice(format!("{} 0 obj\n{}\nendobj\n", index + 1, obj).as_bytes());
    }
    let xref = pdf.len();
    pdf.extend_from_slice(
        format!("xref\n0 {}\n0000000000 65535 f \n", objects.len() + 1).as_bytes(),
    );
    for offset in offsets {
        pdf.extend_from_slice(format!("{offset:010} 00000 n \n").as_bytes());
    }
    pdf.extend_from_slice(
        format!(
            "trailer << /Size {} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF",
            objects.len() + 1
        )
        .as_bytes(),
    );
    pdf
}

fn pdf_response(filename: &str, lines: &[String]) -> AppResult<Response> {
    let mut headers = HeaderMap::new();
    headers.insert(
        header::CONTENT_TYPE,
        HeaderValue::from_static("application/pdf"),
    );
    headers.insert(
        header::CONTENT_DISPOSITION,
        HeaderValue::from_str(&format!("attachment; filename=\"{filename}\""))
            .map_err(|e| AppError::Internal(e.into()))?,
    );
    Ok((headers, ascii_pdf(lines)).into_response())
}

pub(super) async fn export_mise_bas_pdf(
    State(state): State<AppState>,
    Extension(_session): Extension<SessionData>,
    Path(id): Path<i64>,
) -> AppResult<Response> {
    let band: Option<(String, Option<String>, Option<String>)> =
        sqlx::query_as("SELECT code,date_mb,site FROM bande WHERE id=?")
            .bind(id)
            .fetch_optional(&state.pool)
            .await?;
    let Some((code, date, site)) = band else {
        return Err(AppError::NotFound);
    };
    let rows=generic_rows(&state.pool,&format!("SELECT t.num_travail,e.date,e.nes_vifs,e.mort_nes,e.momifies,e.adoptes,e.retires,e.nb_sevres FROM evenement e JOIN truie t ON t.id=e.truie_id WHERE e.bande_id={} AND e.type IN ('mise_bas','sevrage') ORDER BY t.num_travail,e.date",id)).await?;
    let mut lines = vec![
        "EO_Sevel - Registre des mises-bas".into(),
        format!(
            "Bande: {code}   Date: {}   Site: {}",
            date.unwrap_or_else(|| "Date inconnue".into()),
            site.unwrap_or_default()
        ),
        "Truie | Date | NV | MN | Momifies | Adoptes | Retires | Sevres".into(),
    ];
    for row in rows {
        lines.push(format!(
            "{} | {} | {} | {} | {} | {} | {} | {}",
            row["num_travail"],
            row["date"],
            row["nes_vifs"],
            row["mort_nes"],
            row["momifies"],
            row["adoptes"],
            row["retires"],
            row["nb_sevres"]
        ));
    }
    pdf_response(&format!("mises-bas-{code}.pdf"), &lines)
}

pub(super) async fn export_registre_pdf(
    State(state): State<AppState>,
    Extension(_session): Extension<SessionData>,
) -> AppResult<Response> {
    let rows=generic_rows(&state.pool,"SELECT date,type,t.num_travail,b.code AS bande,produit,motif,resultat,note FROM evenement e LEFT JOIN truie t ON t.id=e.truie_id LEFT JOIN bande b ON b.id=e.bande_id ORDER BY date DESC,e.id DESC LIMIT 500").await?;
    let mut lines = vec![
        "EO_Sevel - Registre d'elevage".into(),
        format!("Edition du {}", today_iso()),
        "Date | Type | Animal | Bande | Produit | Motif | Resultat".into(),
    ];
    for row in rows {
        lines.push(format!(
            "{} | {} | {} | {} | {} | {} | {}",
            row["date"],
            row["type"],
            row["num_travail"],
            row["bande"],
            row["produit"],
            row["motif"],
            row["resultat"]
        ));
    }
    pdf_response(&format!("registre-elevage-{}.pdf", today_iso()), &lines)
}

pub(super) async fn journal_supprimer(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
    Path(id): Path<i64>,
    Form(form): Form<HashMap<String, String>>,
) -> AppResult<Response> {
    require_admin(&session)?;
    verify_csrf(&session, &form)?;
    sqlx::query("DELETE FROM journal WHERE id=?")
        .bind(id)
        .execute(&state.pool)
        .await?;
    Ok(Redirect::to("/journal").into_response())
}

fn data_parent(state: &AppState) -> PathBuf {
    state
        .config
        .db_path
        .parent()
        .unwrap_or_else(|| FsPath::new("."))
        .to_path_buf()
}

pub(super) async fn logo(State(state): State<AppState>) -> Response {
    for name in ["logo.png", "logo.jpg", "logo.svg"] {
        let path = data_parent(&state).join(name);
        if let Ok(bytes) = tokio::fs::read(&path).await {
            let content = if name.ends_with("png") {
                "image/png"
            } else if name.ends_with("jpg") {
                "image/jpeg"
            } else {
                "image/svg+xml"
            };
            return ([(header::CONTENT_TYPE, content)], bytes).into_response();
        }
    }
    (StatusCode::NOT_FOUND, "Logo absent").into_response()
}

pub(super) async fn maj(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
) -> AppResult<Html<String>> {
    require_admin(&session)?;
    let marker = data_parent(&state).join("mise-a-jour-en-attente.zip");
    let pending = tokio::fs::metadata(marker).await.ok().map(|m| m.len());
    let mut ctx = context(&session);
    ctx.insert("version".into(), json!(env!("CARGO_PKG_VERSION")));
    ctx.insert("archive_octets".into(), json!(pending));
    ctx.insert(
        "base_nom".into(),
        json!(state
            .config
            .db_path
            .file_name()
            .and_then(|name| name.to_str())
            .unwrap_or("elevage.db")),
    );
    let backup_settings = generic_rows(
        &state.pool,
        "SELECT cle,valeur FROM parametre WHERE cle IN ('nas_path','cloud_path','mail_sauvegarde') ORDER BY cle",
    )
    .await?;
    let mut backup_map = Map::new();
    for row in backup_settings {
        if let Some(key) = row.get("cle").and_then(Value::as_str) {
            backup_map.insert(
                key.to_string(),
                row.get("valeur").cloned().unwrap_or(Value::Null),
            );
        }
    }
    ctx.insert("sauvegarde_reglage".into(), Value::Object(backup_map));
    render(&state, "maj.html", Value::Object(ctx))
}

pub(super) async fn maj_statut(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
) -> AppResult<axum::Json<Value>> {
    require_admin(&session)?;
    let path = data_parent(&state).join("mise-a-jour-statut");
    let content = tokio::fs::read_to_string(path).await.unwrap_or_default();
    let mut lines = content.lines();
    let status = lines.next().unwrap_or("repos");
    let percent = lines
        .next()
        .and_then(|value| value.parse::<i64>().ok())
        .unwrap_or(0)
        .clamp(0, 100);
    let version = lines.next().unwrap_or_default();
    let message = lines.collect::<Vec<_>>().join(" ");
    Ok(axum::Json(json!({
        "statut":status,
        "pourcentage":percent,
        "version":version,
        "message":message
    })))
}

pub(super) async fn maj_lancer(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
    Form(form): Form<HashMap<String, String>>,
) -> AppResult<Response> {
    require_admin(&session)?;
    verify_csrf(&session, &form)?;
    let request = data_parent(&state).join("mise-a-jour-demandee");
    let status = data_parent(&state).join("mise-a-jour-statut");
    tokio::fs::write(
        status,
        "demandee\n2\n\nDemande enregistrée, attente du service système.\n",
    )
    .await
    .map_err(anyhow::Error::from)?;
    tokio::fs::write(&request, format!("{}\n", chrono::Local::now().to_rfc3339()))
        .await
        .map_err(anyhow::Error::from)?;
    db::journal(
        &state.pool,
        &session.nom,
        "demander",
        "mise_a_jour",
        "Demande transmise au service système",
        "/maj/lancer",
    )
    .await;
    Ok(Redirect::to("/maj?demande=1").into_response())
}

pub(super) async fn multipart_fields(
    mut multipart: Multipart,
    file_name: &str,
) -> AppResult<(HashMap<String, String>, Option<Vec<u8>>, Option<String>)> {
    let mut form = HashMap::new();
    let mut file = None;
    let mut uploaded_name = None;
    while let Some(field) = multipart
        .next_field()
        .await
        .map_err(|e| AppError::Invalid(format!("Formulaire invalide: {e}")))?
    {
        let name = field.name().unwrap_or_default().to_string();
        let original = field.file_name().map(str::to_string);
        let bytes = field
            .bytes()
            .await
            .map_err(|e| AppError::Invalid(format!("Téléversement interrompu: {e}")))?;
        if name == file_name {
            uploaded_name = original;
            file = Some(bytes.to_vec());
        } else if let Ok(value) = String::from_utf8(bytes.to_vec()) {
            form.insert(name, value);
        }
    }
    Ok((form, file, uploaded_name))
}

pub(super) async fn maj_zip(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
    multipart: Multipart,
) -> AppResult<Response> {
    require_admin(&session)?;
    let (form, file, _) = multipart_fields(multipart, "fichier").await?;
    verify_csrf(&session, &form)?;
    let bytes = file.ok_or_else(|| AppError::Invalid("Archive ZIP obligatoire".into()))?;
    if !bytes.starts_with(b"PK\x03\x04") {
        return Err(AppError::Invalid(
            "Le fichier n'est pas une archive ZIP valide".into(),
        ));
    }
    let path = data_parent(&state).join("mise-a-jour-en-attente.zip");
    tokio::fs::write(&path, bytes)
        .await
        .map_err(anyhow::Error::from)?;
    db::journal(
        &state.pool,
        &session.nom,
        "deposer",
        "mise_a_jour",
        &path.display().to_string(),
        "/maj/zip",
    )
    .await;
    Ok(Redirect::to("/maj?archive=1").into_response())
}

pub(super) async fn aliment_ajouter(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
    Form(form): Form<HashMap<String, String>>,
) -> AppResult<Response> {
    require_admin(&session)?;
    verify_csrf(&session, &form)?;
    let category = form_text(&form, "categorie")
        .ok_or_else(|| AppError::Invalid("Catégorie obligatoire".into()))?;
    sqlx::query("INSERT INTO planaliment(categorie,jour_debut,jour_fin,aliment,quantite,unite,note,ordre) VALUES(?,?,?,?,?,?,?,?)").bind(category).bind(form_i64(&form,"jour_debut").unwrap_or(0)).bind(form_i64(&form,"jour_fin").unwrap_or(0)).bind(form_text(&form,"aliment")).bind(form_f64(&form,"quantite")).bind(form_text(&form,"unite").unwrap_or_else(||"kg/j".into())).bind(form_text(&form,"note")).bind(form_i64(&form,"ordre").unwrap_or(0)).execute(&state.pool).await?;
    Ok(Redirect::to("/parametres#alimentation").into_response())
}
pub(super) async fn aliment_modifier(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
    Path(id): Path<i64>,
    Form(form): Form<HashMap<String, String>>,
) -> AppResult<Response> {
    require_admin(&session)?;
    verify_csrf(&session, &form)?;
    sqlx::query("UPDATE planaliment SET categorie=?,jour_debut=?,jour_fin=?,aliment=?,quantite=?,unite=?,note=?,ordre=? WHERE id=?").bind(form_text(&form,"categorie")).bind(form_i64(&form,"jour_debut").unwrap_or(0)).bind(form_i64(&form,"jour_fin").unwrap_or(0)).bind(form_text(&form,"aliment")).bind(form_f64(&form,"quantite")).bind(form_text(&form,"unite")).bind(form_text(&form,"note")).bind(form_i64(&form,"ordre").unwrap_or(0)).bind(id).execute(&state.pool).await?;
    Ok(Redirect::to("/parametres#alimentation").into_response())
}
pub(super) async fn aliment_supprimer(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
    Path(id): Path<i64>,
    Form(form): Form<HashMap<String, String>>,
) -> AppResult<Response> {
    require_admin(&session)?;
    verify_csrf(&session, &form)?;
    sqlx::query("DELETE FROM planaliment WHERE id=?")
        .bind(id)
        .execute(&state.pool)
        .await?;
    Ok(Redirect::to("/parametres#alimentation").into_response())
}

pub(super) async fn reglages_maj(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
    Form(form): Form<HashMap<String, String>>,
) -> AppResult<Response> {
    require_admin(&session)?;
    verify_csrf(&session, &form)?;
    let mut tx = state.pool.begin().await?;
    for (key, value) in &form {
        if key == "csrf" {
            continue;
        }
        if let Ok(value) = value.trim().parse::<i64>() {
            if value >= 0 {
                sqlx::query("UPDATE reglage SET valeur=? WHERE cle=?")
                    .bind(value)
                    .bind(key)
                    .execute(&mut *tx)
                    .await?;
            }
        }
    }
    tx.commit().await?;
    Ok(Redirect::to("/parametres#reglages").into_response())
}

pub(super) async fn parametres_maj(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
    Form(form): Form<HashMap<String, String>>,
) -> AppResult<Response> {
    require_admin(&session)?;
    verify_csrf(&session, &form)?;
    let allowed = [
        "nom_elevage",
        "adresse_elevage",
        "telephone_elevage",
        "email_elevage",
        "public_url",
        "echo_j",
        "seuil_stock",
        "nas_path",
        "cloud_path",
        "mail_sauvegarde",
    ];
    let mut tx = state.pool.begin().await?;
    for key in allowed {
        if let Some(value) = form.get(key) {
            sqlx::query("INSERT INTO parametre(cle,valeur) VALUES(?,?) ON CONFLICT(cle) DO UPDATE SET valeur=excluded.valeur").bind(key).bind(value.trim()).execute(&mut *tx).await?;
        }
    }
    // Type d'élevage : seule valeur reconnue parmi les 5 profils (voir 0bis de la
    // spécification) est acceptée ; une soumission corrompue est ignorée en silence.
    let new_type_elevage = form
        .get("type_elevage")
        .map(|v| v.trim().to_string())
        .filter(|v| auth::TYPES_ELEVAGE.iter().any(|(code, _)| code == v));
    if let Some(value) = &new_type_elevage {
        sqlx::query("INSERT INTO parametre(cle,valeur) VALUES('type_elevage',?) ON CONFLICT(cle) DO UPDATE SET valeur=excluded.valeur").bind(value).execute(&mut *tx).await?;
    }
    // Modules optionnels (§0/§2/§4) : ces cases partagent le même formulaire
    // que le type d'élevage (marqueur : le champ type_elevage, un <select>,
    // est toujours présent quand CE formulaire est soumis). Sans ce garde-fou,
    // soumettre un des *autres* formulaires de cette page (qui postent aussi
    // vers /parametres/maj mais n'ont pas de cases à cocher module_*)
    // désactiverait silencieusement les modules à chaque enregistrement.
    let formulaire_type_elevage = form.contains_key("type_elevage");
    if formulaire_type_elevage {
        let module_genetique = form.contains_key("module_genetique");
        let module_prestataires = form.contains_key("module_prestataires");
        let module_charcutiers_rfid = form.contains_key("module_charcutiers_rfid");
        let module_vente_directe = form.contains_key("module_vente_directe");
        sqlx::query("INSERT INTO parametre(cle,valeur) VALUES('module_genetique',?) ON CONFLICT(cle) DO UPDATE SET valeur=excluded.valeur").bind(if module_genetique{"1"}else{"0"}).execute(&mut *tx).await?;
        sqlx::query("INSERT INTO parametre(cle,valeur) VALUES('module_prestataires',?) ON CONFLICT(cle) DO UPDATE SET valeur=excluded.valeur").bind(if module_prestataires{"1"}else{"0"}).execute(&mut *tx).await?;
        sqlx::query("INSERT INTO parametre(cle,valeur) VALUES('module_charcutiers_rfid',?) ON CONFLICT(cle) DO UPDATE SET valeur=excluded.valeur").bind(if module_charcutiers_rfid{"1"}else{"0"}).execute(&mut *tx).await?;
        sqlx::query("INSERT INTO parametre(cle,valeur) VALUES('module_vente_directe',?) ON CONFLICT(cle) DO UPDATE SET valeur=excluded.valeur").bind(if module_vente_directe{"1"}else{"0"}).execute(&mut *tx).await?;
        tx.commit().await?;
        // Les sessions déjà ouvertes voient les nouveaux réglages sans avoir à
        // se reconnecter, pour éviter un affichage incohérent le temps que
        // chacun se reconnecte.
        for mut entry in state.sessions.iter_mut() {
            if let Some(value) = &new_type_elevage {
                entry.value_mut().type_elevage = value.clone();
            }
            entry.value_mut().module_genetique = module_genetique;
            entry.value_mut().module_prestataires = module_prestataires;
            entry.value_mut().module_charcutiers_rfid = module_charcutiers_rfid;
            entry.value_mut().module_vente_directe = module_vente_directe;
        }
    } else {
        tx.commit().await?;
    }
    Ok(Redirect::to("/parametres").into_response())
}

pub(super) async fn demo_actif(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
) -> AppResult<Response> {
    require_admin(&session)?;
    let active: i64 = sqlx::query_scalar("SELECT COUNT(*) FROM demoobjet")
        .fetch_one(&state.pool)
        .await?;
    Ok(axum::Json(json!({"actif":active>0})).into_response())
}

pub(super) async fn demo_basculer(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
    Form(form): Form<HashMap<String, String>>,
) -> AppResult<Response> {
    require_admin(&session)?;
    verify_csrf(&session, &form)?;
    let active: i64 = sqlx::query_scalar("SELECT COUNT(*) FROM demoobjet")
        .fetch_one(&state.pool)
        .await?;
    let mut tx = state.pool.begin().await?;
    if active > 0 {
        // Ordre enfants → parents pour respecter les clés étrangères
        // (foreign_keys=ON) : evenement référence truie et bande,
        // truie/bande référencent site/utilisateur (via engraisseur_id).
        for table in [
            "tache",
            "produitpharmacie",
            "causeperte",
            "evenement",
            "porccharcutier",
            "truie",
            "bande",
            "casesalle",
            "salle",
            "utilisateur",
            "site",
        ] {
            let sql = format!(
                "DELETE FROM {table} WHERE id IN(SELECT row_id FROM demoobjet WHERE table_name=?)"
            );
            sqlx::query(&sql).bind(table).execute(&mut *tx).await?;
        }
        sqlx::query("DELETE FROM demoobjet")
            .execute(&mut *tx)
            .await?;
    } else {
        crate::demo::activer(&mut tx)
            .await
            .map_err(AppError::Internal)?;
    }
    tx.commit().await?;
    Ok(Redirect::to("/parametres#demo").into_response())
}

pub(super) async fn qr_truie(
    State(state): State<AppState>,
    Extension(_session): Extension<SessionData>,
    Path(file): Path<String>,
) -> AppResult<Response> {
    let id = file
        .strip_suffix(".png")
        .unwrap_or(&file)
        .parse::<i64>()
        .map_err(|_| AppError::NotFound)?;
    let number: String = sqlx::query_scalar("SELECT num_travail FROM truie WHERE id=?")
        .bind(id)
        .fetch_optional(&state.pool)
        .await?
        .ok_or(AppError::NotFound)?;
    let code = qrcode::QrCode::new(format!("/truie/{id}?numero={number}").as_bytes())
        .map_err(|e| AppError::Internal(anyhow::anyhow!(e)))?;
    let image = code
        .render::<qrcode::render::svg::Color>()
        .min_dimensions(240, 240)
        .build();
    Ok((
        [(header::CONTENT_TYPE, "image/svg+xml; charset=utf-8")],
        image,
    )
        .into_response())
}

pub(super) async fn salle_lavage(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
    Path(id): Path<i64>,
    Form(form): Form<HashMap<String, String>>,
) -> AppResult<Response> {
    require_writer(&session)?;
    verify_csrf(&session, &form)?;
    let date = form_date_or_today(&form, "date")?;
    sqlx::query("UPDATE salle SET dernier_lavage=? WHERE id=?")
        .bind(date)
        .bind(id)
        .execute(&state.pool)
        .await?;
    Ok(Redirect::to(
        if form.get("retour").map(String::as_str) == Some("taches") {
            "/taches#lavages"
        } else {
            "/structure"
        },
    )
    .into_response())
}

pub(super) async fn sanitaire_generer_protocole(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
    Form(form): Form<HashMap<String, String>>,
) -> AppResult<Response> {
    require_writer(&session)?;
    verify_csrf(&session, &form)?;
    let result=sqlx::query("INSERT INTO acteprotocole(libelle,cible,reference,jour,produit,note,actif,categorie) SELECT 'Traitement - '||trim(e.produit),'porcs','traitement',0,trim(e.produit),'Généré depuis les traitements enregistrés',1,'traitement' FROM evenement e WHERE e.type='traitement' AND trim(COALESCE(e.produit,''))<>'' AND lower(COALESCE(e.motif,'')) NOT LIKE '%vaccin%' AND lower(COALESCE(e.produit,'')) NOT LIKE '%vaccin%' AND NOT EXISTS(SELECT 1 FROM acteprotocole a WHERE a.actif=1 AND lower(trim(a.produit))=lower(trim(e.produit))) GROUP BY lower(trim(e.produit))").execute(&state.pool).await?;
    Ok(Redirect::to(&format!("/sanitaire?generes={}", result.rows_affected())).into_response())
}

pub(super) async fn stock_doses(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
    Form(form): Form<HashMap<String, String>>,
) -> AppResult<Response> {
    require_writer(&session)?;
    verify_csrf(&session, &form)?;
    let product = form_text(&form, "produit")
        .ok_or_else(|| AppError::Invalid("Produit obligatoire".into()))?;
    let doses = form_i64(&form, "doses_unite")
        .filter(|v| *v > 0)
        .ok_or_else(|| AppError::Invalid("Nombre de doses invalide".into()))?;
    let token = product
        .split_whitespace()
        .next()
        .unwrap_or(&product)
        .to_lowercase();
    sqlx::query("UPDATE achatveto SET doses_unite=? WHERE lower(produit) LIKE ?")
        .bind(doses)
        .bind(format!("{token}%"))
        .execute(&state.pool)
        .await?;
    Ok(Redirect::to("/stock").into_response())
}

pub(super) async fn saisie_rapide(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
    Form(form): Form<HashMap<String, String>>,
) -> AppResult<Response> {
    require_writer(&session)?;
    verify_csrf(&session, &form)?;
    let ajax_mode = form.get("ajax").map(|s| s == "1").unwrap_or(false);
    let kind = form_text(&form, "type")
        .ok_or_else(|| AppError::Invalid("Type de saisie obligatoire".into()))?;
    let date = form_date_or_today(&form, "date")?;
    // track updated resources for ajax response
    let mut updated_band_id: Option<i64> = None;
    let mut updated_cases: Vec<i64> = Vec::new();
    match kind.as_str() {
        "perte" => {
            let sow_id = form_i64(&form, "truie_id").ok_or_else(|| {
                AppError::Invalid("Écrivez puis sélectionnez le numéro de la truie".into())
            })?;
            let band_id = if let Some(id) = form_i64(&form, "bande_id") {
                id
            } else {
                sqlx::query_scalar("SELECT COALESCE((SELECT e.bande_id FROM evenement e WHERE e.truie_id=? AND e.type='mise_bas' AND e.bande_id IS NOT NULL ORDER BY e.date DESC,e.id DESC LIMIT 1),(SELECT b.id FROM truie t JOIN bande b ON b.code=t.bande_code WHERE t.id=? ORDER BY b.active DESC,b.id DESC LIMIT 1))")
                    .bind(sow_id).bind(sow_id).fetch_optional(&state.pool).await?.flatten()
                    .ok_or_else(|| AppError::Invalid("Aucune bande trouvée pour cette truie".into()))?
            };
            let band: String = sqlx::query_scalar("SELECT code FROM bande WHERE id=?")
                .bind(band_id)
                .fetch_optional(&state.pool)
                .await?
                .ok_or(AppError::NotFound)?;
            let coherent:i64=sqlx::query_scalar("SELECT COUNT(*) FROM truie t WHERE t.id=? AND (t.bande_code=? OR EXISTS(SELECT 1 FROM evenement e WHERE e.truie_id=t.id AND e.bande_id=? AND e.type='mise_bas'))")
                .bind(sow_id).bind(&band).bind(band_id).fetch_one(&state.pool).await?;
            if coherent == 0 {
                return Err(AppError::Invalid(
                    "La truie ne correspond pas à la bande sélectionnée".into(),
                ));
            }
            let number = form_i64(&form, "nombre").unwrap_or(1).max(1);
            let case_id = form_i64(&form, "case_id");
            let mut stade = form_text(&form, "stade");
            if let Some(case_id) = case_id {
                let deduced = stade_from_case(&state.pool, case_id).await?;
                if deduced.as_deref() == Some("Maternité") {
                    // Vrai bug corrigé ici : les porcelets sous la mère ne
                    // sont jamais comptés par case (aucun inventaire ni
                    // transfert individuel n'est saisi pour eux — seul le
                    // nombre né vivant moins les pertes déjà déclarées fait
                    // foi, comme sur le tableau de maternité). Le contrôle
                    // `case_pig_count`, qui lit `inventairecase`/`transfert`,
                    // renvoyait donc toujours 0 en maternité et bloquait
                    // systématiquement toute perte de porcelet dès qu'une
                    // case était renseignée, avec le message trompeur
                    // « 0 porc(s) présent(s) ».
                    let alive = adoptions::effectif(&state.pool, sow_id, band_id).await?;
                    if number > alive {
                        return Err(AppError::Invalid(format!(
                            "Effectif insuffisant sous la mère : {alive} porcelet(s) présent(s)"
                        )));
                    }
                } else {
                    let present = case_pig_count(&state.pool, case_id).await?;
                    if number > present {
                        return Err(AppError::Invalid(format!(
                            "Effectif insuffisant dans la case : {present} porc(s) présent(s)"
                        )));
                    }
                }
                stade = deduced.or(stade);
            }
            let cause = form_text(&form, "cause")
                .ok_or_else(|| AppError::Invalid("Cause obligatoire".into()))?;
            let cause_exists: i64 =
                sqlx::query_scalar("SELECT COUNT(*) FROM causeperte WHERE lower(libelle)=lower(?)")
                    .bind(&cause)
                    .fetch_one(&state.pool)
                    .await?;
            if cause_exists == 0 {
                return Err(AppError::Invalid(
                    "Sélectionnez une cause configurée".into(),
                ));
            }
            // `horodatage` est renseigné explicitement, jamais laissé au
            // DEFAULT de la table : les bases héritées de la 1.65 portent la
            // colonne en NOT NULL sans valeur par défaut, et `CREATE TABLE IF
            // NOT EXISTS` ne redéfinit pas une table déjà présente. Compter
            // sur le défaut faisait échouer toute déclaration de mortalité sur
            // ces bases — et seulement sur elles — avec « NOT NULL constraint
            // failed: declarationmort.horodatage ».
            sqlx::query("INSERT INTO declarationmort(horodatage,bande_code,date,stade,case_id,cause,poids,nombre,declare_par,note) VALUES(CURRENT_TIMESTAMP,?,?,?,?,?,?,?,?,?)").bind(band).bind(&date).bind(stade).bind(case_id).bind(&cause).bind(form_f64(&form,"poids")).bind(number).bind(&session.nom).bind(form_text(&form,"note")).execute(&state.pool).await?;
            // L'âge n'est plus demandé à la saisie : il se calcule depuis la
            // mise-bas, et c'est lui qui permet d'étudier ensuite à quel
            // moment de la lactation les pertes surviennent. On cherche donc
            // la mise-bas de la bande, puis, à défaut, la dernière mise-bas
            // de la truie antérieure à la perte — une truie déplacée de bande
            // ne doit pas faire perdre l'information.
            let farrowing: Option<String> = sqlx::query_scalar(
                "SELECT COALESCE( \
                   (SELECT date FROM evenement WHERE truie_id=? AND bande_id=? AND type='mise_bas' AND date<=? ORDER BY date DESC,id DESC LIMIT 1), \
                   (SELECT date FROM evenement WHERE truie_id=? AND type='mise_bas' AND date<=? ORDER BY date DESC,id DESC LIMIT 1))",
            )
            .bind(sow_id)
            .bind(band_id)
            .bind(&date)
            .bind(sow_id)
            .bind(&date)
            .fetch_optional(&state.pool)
            .await?
            .flatten();
            let age = farrowing
                .as_deref()
                .and_then(parse_stored_date)
                .and_then(|start| parse_stored_date(&date).map(|end| (end - start).num_days()))
                .filter(|value| *value >= 0);
            sqlx::query("INSERT INTO perteporcelet(truie_id,bande_id,age_j,nb,cause,date) VALUES(?,?,?,?,?,?)").bind(sow_id).bind(band_id).bind(age).bind(number).bind(cause).bind(&date).execute(&state.pool).await?;
        }
        "sortie" => {
            let sow_id = form_i64(&form, "truie_id")
                .ok_or_else(|| AppError::Invalid("Truie obligatoire".into()))?;
            let reason = form_text(&form, "motif")
                .ok_or_else(|| AppError::Invalid("Motif obligatoire".into()))?;
            if !SOW_EXIT_REASONS.contains(&reason.as_str()) {
                return Err(AppError::Invalid(
                    "Sélectionnez un motif de sortie proposé".into(),
                ));
            }
            sqlx::query("UPDATE truie SET reformee=1,statut='sortie',date_reforme=?,motif_sortie=?,updated_at=CURRENT_TIMESTAMP WHERE id=?").bind(date).bind(reason).bind(sow_id).execute(&state.pool).await?;
        }
        "eld" => {
            let sow_id = form_i64(&form, "truie_id")
                .ok_or_else(|| AppError::Invalid("Truie obligatoire".into()))?;
            let eld = form_f64(&form, "eld").filter(|v| *v >= 0.0);
            let poids = form_f64(&form, "poids").filter(|v| *v >= 0.0);
            let nec = form_f64(&form, "nec").filter(|v| (1.0..=5.0).contains(v));
            if eld.is_none() && poids.is_none() && nec.is_none() {
                return Err(AppError::Invalid(
                    "Saisissez au moins l’ELD, le poids ou la NEC".into(),
                ));
            }
            sqlx::query("INSERT INTO mesuretruie(truie_id,date,periode,eld,poids,nec,note) VALUES(?,?,?,?,?,?,?)").bind(sow_id).bind(date).bind(form_text(&form,"periode")).bind(eld).bind(poids).bind(nec).bind(form_text(&form,"note")).execute(&state.pool).await?;
        }
        // Une cochette entre au cheptel avec tout ce qui servira ensuite à la
        // juger : sa filiation, sa lignée, son poids et sa date de naissance.
        // Ces informations ne se retrouvent plus après coup, alors qu'elles
        // conditionnent l'analyse de sa carrière — d'où leur saisie ici, au
        // moment où l'animal arrive, plutôt que dans un écran séparé.
        "cochette" => {
            let numero = form_text(&form, "num_travail")
                .ok_or_else(|| AppError::Invalid("N° de travail obligatoire".into()))?;
            let existe: i64 =
                sqlx::query_scalar("SELECT COUNT(*) FROM truie WHERE num_travail=? AND reformee=0")
                    .bind(&numero)
                    .fetch_one(&state.pool)
                    .await?;
            if existe > 0 {
                return Err(AppError::Invalid(format!(
                    "Le numéro {numero} est déjà porté par une truie au cheptel"
                )));
            }
            // La lignée n'existe qu'avec le module Génétique avancée : une
            // valeur envoyée sans lui est ignorée plutôt que refusée.
            let lignee_id = session
                .module_genetique
                .then(|| form_i64(&form, "lignee_id"))
                .flatten();
            let naissance = form_text(&form, "date_naissance");
            let mut tx = state.pool.begin().await?;
            let cochette = sqlx::query(
                "INSERT INTO truie(num_travail,num_national,rfid,race,date_naissance,date_entree,bande_code,lignee_id,pere_national,mere_national,statut,reformee,rang,mere_cochette) \
                 VALUES(?,?,?,?,?,?,?,?,?,?,'active',0,0,0)",
            )
            .bind(&numero)
            .bind(form_text(&form, "num_national"))
            .bind(form_text(&form, "rfid"))
            .bind(form_text(&form, "race"))
            .bind(naissance)
            .bind(&date)
            .bind(form_text(&form, "bande_code"))
            .bind(lignee_id)
            .bind(form_text(&form, "pere_national"))
            .bind(form_text(&form, "mere_national"))
            .execute(&mut *tx)
            .await?
            .last_insert_rowid();
            // Le poids d'entrée rejoint les mesures : c'est le même suivi que
            // les pesées suivantes, il apparaît donc dans la courbe de la
            // truie sans traitement particulier.
            if let Some(poids) = form_f64(&form, "poids") {
                sqlx::query(
                    "INSERT INTO mesuretruie(truie_id,date,poids,periode) VALUES(?,?,?,'Entrée quarantaine')",
                )
                .bind(cochette)
                .bind(&date)
                .bind(poids)
                .execute(&mut *tx)
                .await?;
            }
            tx.commit().await?;
            if ajax_mode {
                return Ok(axum::Json(json!({"ok":true,"truie_id":cochette})).into_response());
            }
            return Ok(Redirect::to(&format!("/truie/{cochette}")).into_response());
        }
        "mise_bas" => {
            let sow_id = form_i64(&form, "truie_id")
                .ok_or_else(|| AppError::Invalid("Truie obligatoire".into()))?;
            let band_id = sow_band(&state.pool, sow_id).await?;
            let case_id: Option<i64> = sqlx::query_scalar("SELECT case_id FROM truie WHERE id=?")
                .bind(sow_id)
                .fetch_optional(&state.pool)
                .await?
                .flatten();
            let live = form_i64(&form, "nes_vifs").unwrap_or(0).max(0);
            let still = form_i64(&form, "mort_nes").unwrap_or(0).max(0);
            let mummies = form_i64(&form, "momifies").unwrap_or(0).max(0);
            let weak = form_i64(&form, "chetifs").unwrap_or(0).max(0);
            let crushed = form_i64(&form, "ecrases").unwrap_or(0).max(0);
            let killed = form_i64(&form, "tues_truie").unwrap_or(0).max(0);
            // Les porcelets aux pattes écartées sont vivants : ils sont déjà
            // dans les nés vifs et ne doivent surtout pas en être retirés.
            // C'est une observation de portée, conservée sur la truie comme
            // critère de sélection des mères à cochettes.
            let splayleg = form_i64(&form, "splayleg").filter(|n| *n >= 0);
            let total = live + still + mummies;
            let existing: Option<i64> = sqlx::query_scalar(
                "SELECT id FROM evenement WHERE truie_id=? AND type='mise_bas' AND bande_id IS ? ORDER BY id DESC LIMIT 1",
            )
            .bind(sow_id)
            .bind(band_id)
            .fetch_optional(&state.pool)
            .await?;
            let mut tx = state.pool.begin().await?;
            let event_id = if let Some(event_id) = existing {
                sqlx::query("UPDATE evenement SET date=?,nes_totaux=?,nes_vifs=?,mort_nes=?,momifies=?,chetifs=?,ecrases=?,tues_truie=?,heure_debut=?,heure_fin=?,suivi_actif=?,delivrance_ok=?,note=?,case_id=COALESCE(case_id,?) WHERE id=?")
                    .bind(&date).bind(total).bind(live).bind(still).bind(mummies).bind(weak).bind(crushed).bind(killed)
                    .bind(form_text(&form,"heure_debut")).bind(form_text(&form,"heure_fin")).bind(form.contains_key("suivi_actif") as i64).bind(form_i64(&form,"delivrance_ok")).bind(form_text(&form,"note")).bind(case_id)
                    .bind(event_id).execute(&mut *tx).await?;
                if let Some(splayleg) = splayleg {
                    sqlx::query(
                        "UPDATE truie SET splayleg=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",
                    )
                    .bind(splayleg)
                    .bind(sow_id)
                    .execute(&mut *tx)
                    .await?;
                }
                event_id
            } else {
                let result = sqlx::query("INSERT INTO evenement(type,date,truie_id,bande_id,nes_totaux,nes_vifs,mort_nes,momifies,chetifs,ecrases,tues_truie,heure_debut,heure_fin,suivi_actif,delivrance_ok,note,case_id) VALUES('mise_bas',?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
                    .bind(&date).bind(sow_id).bind(band_id).bind(total).bind(live).bind(still).bind(mummies).bind(weak).bind(crushed).bind(killed)
                    .bind(form_text(&form,"heure_debut")).bind(form_text(&form,"heure_fin")).bind(form.contains_key("suivi_actif") as i64).bind(form_i64(&form,"delivrance_ok")).bind(form_text(&form,"note")).bind(case_id)
                    .execute(&mut *tx).await?;
                if let Some(splayleg) = splayleg {
                    sqlx::query(
                        "UPDATE truie SET splayleg=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",
                    )
                    .bind(splayleg)
                    .bind(sow_id)
                    .execute(&mut *tx)
                    .await?;
                }
                if parse_stored_date(&date).is_some_and(|day| day <= Local::now().date_naive()) {
                    sqlx::query(
                        "UPDATE truie SET rang=rang+1,updated_at=CURRENT_TIMESTAMP WHERE id=?",
                    )
                    .bind(sow_id)
                    .execute(&mut *tx)
                    .await?;
                }
                result.last_insert_rowid()
            };
            if let Some(band_id) = band_id {
                sqlx::query("UPDATE truie SET bande_code=(SELECT code FROM bande WHERE id=?),perf_nt=?,perf_nv=?,perf_mn=?,perf_mo=?,updated_at=CURRENT_TIMESTAMP WHERE id=?")
                    .bind(band_id).bind(total as f64).bind(live as f64).bind(still as f64).bind(mummies as f64).bind(sow_id)
                    .execute(&mut *tx).await?;
                updated_band_id = Some(band_id);
            }
            tx.commit().await?;
            synchroniser_pertes_mise_bas(
                &state.pool,
                event_id,
                sow_id,
                band_id,
                &date,
                (weak, crushed, killed),
            )
            .await?;
            synchroniser_soins_portee(&state.pool, event_id, sow_id, band_id, &date).await?;
        }
        "ia" | "echo" | "chaleur" => {
            let sow_id = form_i64(&form, "truie_id")
                .ok_or_else(|| AppError::Invalid("Truie obligatoire".into()))?;
            let band_id = sow_band(&state.pool, sow_id).await?;
            let slots = ia_slots(&form);
            if kind == "ia" && slots.is_empty() {
                return Err(AppError::Invalid(
                    "Cochez matin, midi ou soir pour l'insémination".into(),
                ));
            }
            let dose_count = (kind == "ia").then_some(slots.len() as i64);
            let slot_text = (!slots.is_empty()).then(|| slots.join(","));
            sqlx::query("INSERT INTO evenement(type,date,truie_id,bande_id,resultat,produit,nb_doses,creneaux_ia,note) VALUES(?,?,?,?,?,?,?,?,?)").bind(&kind).bind(date).bind(sow_id).bind(band_id).bind(form_text(&form,"resultat")).bind(form_text(&form,"produit")).bind(dose_count).bind(slot_text).bind(form_text(&form,"note")).execute(&state.pool).await?;
        }
        "sevrage" => {
            // traitement batch de sevrage depuis la saisie rapide
            let band_id = form_i64(&form, "bande_id")
                .ok_or_else(|| AppError::Invalid("Bande obligatoire".into()))?;
            let band_code: String = sqlx::query_scalar("SELECT code FROM bande WHERE id=?")
                .bind(band_id)
                .fetch_optional(&state.pool)
                .await?
                .ok_or(AppError::NotFound)?;
            let _mode = form
                .get("sevrage_mode")
                .map(|s| s.as_str())
                .unwrap_or("toute");
            let sel = form
                .get("sevrage_truies")
                .ok_or_else(|| AppError::Invalid("Truies manquantes".into()))?;
            let distrib = form
                .get("sevrage_distribution")
                .ok_or_else(|| AppError::Invalid("Répartition manquante".into()))?;
            let selected: Vec<serde_json::Value> = serde_json::from_str(sel)
                .map_err(|_| AppError::Invalid("Données truies invalides".into()))?;
            let dist: Vec<serde_json::Value> = serde_json::from_str(distrib)
                .map_err(|_| AppError::Invalid("Données répartition invalides".into()))?;
            // calculs
            let mut total_selected: i64 = 0;
            let mut sows: Vec<(i64, i64)> = Vec::new();
            let mut seen_sows = HashSet::new();
            for item in selected.iter() {
                let id = item
                    .get("id")
                    .and_then(Value::as_i64)
                    .ok_or_else(|| AppError::Invalid("Truie invalide".into()))?;
                let nb = item
                    .get("nb")
                    .and_then(Value::as_i64)
                    .filter(|nb| *nb >= 0)
                    .ok_or_else(|| AppError::Invalid("Effectif invalide".into()))?;
                if !seen_sows.insert(id) {
                    return Err(AppError::Invalid(
                        "Truie sélectionnée plusieurs fois".into(),
                    ));
                }
                sows.push((id, nb));
                total_selected = total_selected
                    .checked_add(nb)
                    .ok_or_else(|| AppError::Invalid("Effectif trop élevé".into()))?;
            }
            if sows.is_empty() {
                return Err(AppError::Invalid("Sélectionnez au moins une truie".into()));
            }
            let mut total_dist: i64 = 0;
            let mut dlines: Vec<(i64, i64)> = Vec::new();
            let mut seen_cases = HashSet::new();
            for item in dist.iter() {
                let case_id = item
                    .get("case_id")
                    .and_then(Value::as_i64)
                    .ok_or_else(|| AppError::Invalid("Case invalide".into()))?;
                let nb = item
                    .get("nombre")
                    .and_then(Value::as_i64)
                    .filter(|nb| *nb >= 0)
                    .ok_or_else(|| AppError::Invalid("Répartition invalide".into()))?;
                if !seen_cases.insert(case_id) {
                    return Err(AppError::Invalid("Case sélectionnée plusieurs fois".into()));
                }
                dlines.push((case_id, nb));
                total_dist = total_dist
                    .checked_add(nb)
                    .ok_or_else(|| AppError::Invalid("Effectif trop élevé".into()))?;
            }
            if total_dist != total_selected {
                return Err(AppError::Invalid(
                    "La somme des porcelets répartis doit correspondre au total sélectionné".into(),
                ));
            }
            let mut tx = state.pool.begin_with("BEGIN IMMEDIATE").await?;
            // pour chaque truie, enregistrer evenement sevrage (même si nb==0)
            // avant d'enregistrer, vérifier qu'aucune truie sélectionnée n'a déjà un sevrage à la même date ou après
            for (sow_id, nb) in sows.iter() {
                let belongs: i64 = sqlx::query_scalar(
                    "SELECT COUNT(*) FROM truie WHERE id=? AND reformee=0 AND bande_code=?",
                )
                .bind(sow_id)
                .bind(&band_code)
                .fetch_one(&mut *tx)
                .await?;
                if belongs != 1 {
                    return Err(AppError::Invalid("Truie absente de cette bande".into()));
                }
                let last_sev: Option<String> = sqlx::query_scalar("SELECT date FROM evenement WHERE truie_id=? AND type='sevrage' ORDER BY date DESC,id DESC LIMIT 1").bind(sow_id).fetch_optional(&mut *tx).await?;
                if let (Some(last), Some(given)) = (last_sev.as_deref(), parse_stored_date(&date)) {
                    if let Some(ld) = parse_stored_date(last) {
                        if ld >= given {
                            return Err(AppError::Invalid(format!(
                                "Truie {} déjà sevrée le {}",
                                sow_id, last
                            )));
                        }
                    }
                }
                let existing:Option<i64> = sqlx::query_scalar("SELECT id FROM evenement WHERE truie_id=? AND type='sevrage' AND bande_id IS ? ORDER BY id DESC LIMIT 1").bind(sow_id).bind(band_id).fetch_optional(&mut *tx).await?;
                if existing.is_some() {
                    return Err(AppError::Invalid(
                        "Ce sevrage existe déjà ; corrigez-le depuis la fiche de la truie".into(),
                    ));
                } else {
                    sqlx::query("INSERT INTO evenement(type,date,truie_id,bande_id,nb_sevres,note) VALUES('sevrage',?,?,?,?,?)").bind(&date).bind(sow_id).bind(band_id).bind(*nb).bind(form_text(&form,"note")).execute(&mut *tx).await?;
                }
                // mettre à jour la truie (perf_sevres + potentiellement nettoyage bande_code)
                sqlx::query(
                    "UPDATE truie SET perf_sevres=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",
                )
                .bind(*nb as f64)
                .bind(sow_id)
                .execute(&mut *tx)
                .await?;
                sqlx::query("UPDATE truie SET bande_code=CASE WHEN date(?)<=date('now') AND bande_code=(SELECT code FROM bande WHERE id=?) THEN NULL ELSE bande_code END,updated_at=CURRENT_TIMESTAMP WHERE id=?").bind(&date).bind(band_id).bind(sow_id).execute(&mut *tx).await?;
            }
            // Vérification de capacité : pour chaque case destination, s'assurer que la somme actuelle + nb ne dépasse pas nb_max_porcs si défini
            for (case_id, nb) in dlines.iter() {
                if *nb <= 0 {
                    continue;
                }
                // récupérer capacité
                let cap_opt: Option<i64> =
                    sqlx::query_scalar("SELECT nb_max_porcs FROM casesalle WHERE id=?")
                        .bind(case_id)
                        .fetch_optional(&mut *tx)
                        .await?
                        .ok_or_else(|| {
                            AppError::Invalid("Case de destination introuvable".into())
                        })?;
                if let Some(cap) = cap_opt {
                    let occupancy = case_pig_count_conn(&mut tx, *case_id).await?.max(0);
                    if *nb > cap.saturating_sub(occupancy) {
                        return Err(AppError::Invalid(format!(
                            "La case {} ne peut pas accueillir {} porcelet(s) (capacité {}, occupés {}).",
                            case_id, nb, cap, occupancy
                        )));
                    }
                }
            }
            // insert mouvementstock pour chaque destination
            for (case_id, nb) in dlines.iter() {
                if *nb > 0 {
                    sqlx::query("INSERT INTO mouvementstock(date,bande_code,nombre,libelle,destination,type_saisie,est_stock) VALUES(?,?,?,?,?,'sevrage',0)")
                        .bind(&date).bind(&band_code).bind(*nb).bind("Sevrage").bind(format!("case:{}",case_id)).execute(&mut *tx).await?;
                    sqlx::query("INSERT INTO transfert(date,espece,bande_id,case_dest_id,salle_dest_id,nombre,note) VALUES(?,'porc',?,?,(SELECT salle_id FROM casesalle WHERE id=?),?,'Entrée de porcelets sevrés')")
                        .bind(&date).bind(band_id).bind(case_id).bind(case_id).bind(nb).execute(&mut *tx).await?;
                    // L'arrivée réelle rend le préconditionnement obsolète :
                    // la régulation lit désormais ce vrai transfert.
                    sqlx::query("DELETE FROM ambiance_preconditionnement WHERE salle_id=(SELECT salle_id FROM casesalle WHERE id=?)")
                        .bind(case_id).execute(&mut *tx).await?;
                }
            }
            // maj bande.cs_total_sevres
            if total_selected > 0 {
                sqlx::query(
                    "UPDATE bande SET cs_total_sevres=COALESCE(cs_total_sevres,0)+? WHERE id=?",
                )
                .bind(total_selected)
                .bind(band_id)
                .execute(&mut *tx)
                .await?;
            }
            tx.commit().await?;
            // remember updated band and cases for ajax response
            updated_band_id = Some(band_id);
            for (case_id, _nb) in dlines.iter() {
                updated_cases.push(*case_id);
            }
        }
        "comportement" => {
            let band_id = form_i64(&form, "bande_id")
                .ok_or_else(|| AppError::Invalid("Bande obligatoire".into()))?;
            sqlx::query_scalar::<_, i64>("SELECT id FROM bande WHERE id=?")
                .bind(band_id)
                .fetch_optional(&state.pool)
                .await?
                .ok_or_else(|| AppError::Invalid("Bande introuvable".into()))?;
            let categorie = form_text(&form, "categorie")
                .ok_or_else(|| AppError::Invalid("Catégorie obligatoire".into()))?;
            if !["cannibalisme", "queue_mordue", "oreille_mordue", "autre"]
                .contains(&categorie.as_str())
            {
                return Err(AppError::Invalid("Catégorie inconnue".into()));
            }
            let gravite = form_text(&form, "gravite").unwrap_or_else(|| "debut".into());
            if !["debut", "aggravation", "perte_inexpliquee"].contains(&gravite.as_str()) {
                return Err(AppError::Invalid("Gravité inconnue".into()));
            }
            let case_id = form_i64(&form, "case_id");
            let salle_id = match case_id {
                Some(case_id) => {
                    let salle_id: Option<i64> =
                        sqlx::query_scalar("SELECT salle_id FROM casesalle WHERE id=?")
                            .bind(case_id)
                            .fetch_optional(&state.pool)
                            .await?
                            .ok_or_else(|| AppError::Invalid("Case introuvable".into()))?;
                    salle_id
                }
                None => None,
            };
            let nombre = form_i64(&form, "nombre").filter(|n| *n >= 0);
            sqlx::query("INSERT INTO observation_comportement(date,bande_id,case_id,salle_id,categorie,gravite,nombre,note,utilisateur) VALUES(?,?,?,?,?,?,?,?,?)")
                .bind(&date)
                .bind(band_id)
                .bind(case_id)
                .bind(salle_id)
                .bind(&categorie)
                .bind(&gravite)
                .bind(nombre)
                .bind(form_text(&form, "note"))
                .bind(&session.nom)
                .execute(&state.pool)
                .await?;
            updated_band_id = Some(band_id);
            if let Some(case_id) = case_id {
                updated_cases.push(case_id);
            }
        }
        _ => return Err(AppError::Invalid("Type de saisie non reconnu".into())),
    }
    if ajax_mode {
        // return a JSON summary for client-side refresh
        let resp = json!({"ok": true, "band_id": updated_band_id, "cases": updated_cases});
        return Ok(axum::Json(resp).into_response());
    }
    Ok(Redirect::to("/?saisie=ok").into_response())
}

/// Tables du socle historique (`db::TABLES_SOCLE`) absentes d'une
/// sauvegarde candidate. Volontairement indifférent aux tables ajoutées
/// après coup : celles-ci sont recréées par `db::init` au redémarrage, donc
/// leur absence ne dit rien sur la validité de la sauvegarde.
fn tables_socle_manquantes(candidate_tables: &[String]) -> Vec<&'static str> {
    db::TABLES_SOCLE
        .iter()
        .filter(|table| !candidate_tables.iter().any(|t| t == *table))
        .copied()
        .collect()
}

#[cfg(test)]
mod tables_socle_tests {
    use super::*;

    #[test]
    fn une_sauvegarde_plus_ancienne_sans_les_dernieres_tables_nest_pas_signalee() {
        // Exactement le cas rencontré : une sauvegarde d'avant l'ajout de
        // ventilateur_salle/observation_comportement/ambiance_preconditionnement
        // contient tout le socle, elle ne doit rien manquer.
        let candidate: Vec<String> = db::TABLES_SOCLE.iter().map(|t| t.to_string()).collect();
        assert!(tables_socle_manquantes(&candidate).is_empty());
    }

    #[test]
    fn une_sauvegarde_sans_table_du_socle_est_signalee() {
        let mut candidate: Vec<String> = db::TABLES_SOCLE.iter().map(|t| t.to_string()).collect();
        candidate.retain(|t| t != "truie");
        let manquantes = tables_socle_manquantes(&candidate);
        assert_eq!(manquantes, vec!["truie"]);
    }

    #[test]
    fn une_base_totalement_vide_est_signalee_avec_tout_le_socle() {
        let manquantes = tables_socle_manquantes(&[]);
        assert_eq!(manquantes.len(), db::TABLES_SOCLE.len());
    }
}

pub(super) async fn sauvegarde_restaurer(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
    multipart: Multipart,
) -> AppResult<Response> {
    require_admin(&session)?;
    let (form, file, _) = multipart_fields(multipart, "fichier").await?;
    verify_csrf(&session, &form)?;
    if form.get("confirmation").map(String::as_str) != Some("RESTAURER") {
        return Err(AppError::Invalid(
            "Tapez RESTAURER pour confirmer le remplacement de la base".into(),
        ));
    }
    let bytes = file.ok_or_else(|| AppError::Invalid("Sauvegarde SQLite obligatoire".into()))?;
    if bytes.len() > 128 * 1024 * 1024 {
        return Err(AppError::Invalid(
            "Sauvegarde trop volumineuse (maximum 128 Mo)".into(),
        ));
    }
    if !bytes.starts_with(b"SQLite format 3\0") {
        return Err(AppError::Invalid(
            "Le fichier n'est pas une base SQLite".into(),
        ));
    }
    let parent = data_parent(&state);
    let timestamp = Local::now().format("%Y%m%d-%H%M%S").to_string();
    let candidate = parent.join(format!("restauration-validee-{timestamp}.db"));
    tokio::fs::write(&candidate, &bytes)
        .await
        .map_err(anyhow::Error::from)?;
    let options = sqlx::sqlite::SqliteConnectOptions::new()
        .filename(&candidate)
        .read_only(true);
    let check_pool = sqlx::sqlite::SqlitePoolOptions::new()
        .max_connections(1)
        .connect_with(options)
        .await?;
    let check: String = sqlx::query_scalar("PRAGMA quick_check")
        .fetch_one(&check_pool)
        .await?;
    // Socle historique (voir `db::TABLES_SOCLE`), pas la base *actuelle* qui
    // grossit à chaque fonctionnalité ajoutée : les migrations sont
    // additives (`db::init` s'exécute à chaque démarrage et complète toute
    // base plus ancienne, 1.55 à 1.65 comprises, sans rien effacer), donc une
    // sauvegarde qui date d'avant une nouvelle table sera mise à niveau
    // toute seule au redémarrage. La refuser pour cette seule raison
    // empêcherait tout retour en arrière légitime.
    let candidate_tables: Vec<String> = sqlx::query_scalar("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")
        .fetch_all(&check_pool).await?;
    // Raisons précises du refus, plutôt qu'un message générique : c'est ce
    // qui permet de distinguer une sauvegarde réellement corrompue ou
    // incompatible (socle absent) d'une simple base ancienne — que
    // `db::init` sait de toute façon compléter.
    let mut raisons = Vec::new();
    if check != "ok" {
        raisons.push(format!("intégrité SQLite : {check}"));
    }
    let tables_manquantes = tables_socle_manquantes(&candidate_tables);
    if !tables_manquantes.is_empty() {
        raisons.push(format!(
            "tables absentes de la sauvegarde : {}",
            tables_manquantes.join(", ")
        ));
    }
    let foreign_key_errors = sqlx::query("PRAGMA foreign_key_check")
        .fetch_all(&check_pool)
        .await?;
    check_pool.close().await;
    if !foreign_key_errors.is_empty() {
        raisons.push(format!(
            "{} référence(s) invalide(s) entre tables",
            foreign_key_errors.len()
        ));
    }
    if !raisons.is_empty() {
        let _ = tokio::fs::remove_file(&candidate).await;
        let detail = raisons.join(" · ");
        let conseil = if tables_manquantes.is_empty() {
            ""
        } else {
            " Cette sauvegarde est probablement antérieure à une mise à jour du logiciel : \
             restaurez-la sur la version de l'application qui l'a produite, ou reprenez une \
             sauvegarde plus récente."
        };
        return Err(AppError::Invalid(format!(
            "Sauvegarde refusée — {detail}.{conseil}"
        )));
    }
    sqlx::query("PRAGMA wal_checkpoint(FULL)")
        .execute(&state.pool)
        .await?;
    let backup = parent.join(format!("avant-restauration-{timestamp}.db"));
    tokio::fs::copy(&state.config.db_path, &backup)
        .await
        .map_err(anyhow::Error::from)?;
    db::journal(
        &state.pool,
        &session.nom,
        "restaurer",
        "sauvegarde",
        &backup.display().to_string(),
        "/sauvegarde/restaurer",
    )
    .await;
    let pool = state.pool.clone();
    let live = state.config.db_path.clone();
    tokio::spawn(async move {
        tokio::time::sleep(std::time::Duration::from_millis(800)).await;
        pool.close().await;
        for suffix in ["-wal", "-shm"] {
            let old = PathBuf::from(format!("{}{suffix}", live.display()));
            if tokio::fs::metadata(&old).await.is_ok() {
                let archived = PathBuf::from(format!("{}.ancien{suffix}", live.display()));
                let _ = tokio::fs::rename(old, archived).await;
            }
        }
        if tokio::fs::rename(candidate, live).await.is_ok() {
            std::process::exit(1);
        }
    });
    Ok(Html(String::from("<!doctype html><meta charset='utf-8'><h1>Restauration validée</h1><p>La base a été contrôlée et le service redémarre. Rechargez la page dans quelques secondes.</p>")).into_response())
}

#[derive(Clone)]
struct CommSettings {
    api_key: String,
    sender_email: String,
    sender_name: String,
    sms_sender: String,
}
async fn comm_settings(pool: &SqlitePool) -> AppResult<CommSettings> {
    let row:Option<(Option<String>,Option<String>,String,String)>=sqlx::query_as("SELECT brevo_api_key,sender_email,sender_name,sms_sender FROM reglagecommunicationventedirecte WHERE id=1").fetch_optional(pool).await?;
    let Some((key, email, name, sms)) = row else {
        return Err(AppError::Invalid(
            "Configurez d'abord les communications Brevo".into(),
        ));
    };
    let api_key = key
        .filter(|v| !v.trim().is_empty())
        .ok_or_else(|| AppError::Invalid("Clé API Brevo absente".into()))?;
    let sender_email = email
        .filter(|v| v.contains('@'))
        .ok_or_else(|| AppError::Invalid("Adresse expéditeur absente".into()))?;
    Ok(CommSettings {
        api_key,
        sender_email,
        sender_name: name,
        sms_sender: sms,
    })
}

async fn brevo_send(
    settings: &CommSettings,
    channel: &str,
    to: &str,
    name: &str,
    subject: &str,
    content: &str,
) -> Result<String, String> {
    if crate::demo_portal::enabled() {
        return Err("Envoi externe désactivé en démonstration".into());
    }
    let client = reqwest::Client::new();
    let (url, payload) = if channel == "email" {
        (
            "https://api.brevo.com/v3/smtp/email",
            json!({"sender":{"name":settings.sender_name,"email":settings.sender_email},"to":[{"email":to,"name":name}],"subject":subject,"htmlContent":content}),
        )
    } else {
        (
            "https://api.brevo.com/v3/transactionalSMS/sms",
            json!({"sender":settings.sms_sender,"recipient":to,"content":content,"type":"transactional","tag":"eo-sevel"}),
        )
    };
    let response = client
        .post(url)
        .header("api-key", &settings.api_key)
        .json(&payload)
        .send()
        .await
        .map_err(|e| e.to_string())?;
    let status = response.status();
    let body = response.text().await.unwrap_or_default();
    if status.is_success() {
        Ok(body)
    } else {
        Err(format!("HTTP {status}: {body}"))
    }
}

async fn log_message(
    pool: &SqlitePool,
    client_id: Option<i64>,
    channel: &str,
    kind: &str,
    to: &str,
    content: &str,
    result: &Result<String, String>,
) -> AppResult<()> {
    sqlx::query("INSERT INTO messageventedirecte(client_id,canal,type_message,destinataire,contenu,succes,detail) VALUES(?,?,?,?,?,?,?)").bind(client_id).bind(channel).bind(kind).bind(to).bind(content).bind(result.is_ok()).bind(match result{Ok(v)|Err(v)=>v}).execute(pool).await?;
    Ok(())
}

fn escape_html(value: &str) -> String {
    value
        .replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
        .replace('"', "&quot;")
        .replace('\'', "&#39;")
}

pub(super) struct RecapCommande<'a> {
    pub order_id: i64,
    pub client_id: Option<i64>,
    pub destinataire: &'a str,
    pub nom_client: &'a str,
    pub token: &'a str,
    pub code: &'a str,
    pub total: f64,
    pub lignes: &'a [(String, f64, String, f64)],
}

pub(super) async fn envoyer_recap_commande(
    pool: &SqlitePool,
    recap: RecapCommande<'_>,
) -> AppResult<()> {
    let RecapCommande {
        order_id,
        client_id,
        destinataire,
        nom_client,
        token,
        code,
        total,
        lignes,
    } = recap;
    let settings = comm_settings(pool).await?;
    let public_url: Option<String> =
        sqlx::query_scalar("SELECT valeur FROM parametre WHERE cle='public_url'")
            .fetch_optional(pool)
            .await?;
    let path = format!("/commande/modifier/{token}");
    let link = public_url
        .as_deref()
        .map(str::trim)
        .filter(|value| !value.is_empty())
        .map(|value| format!("{}{path}", value.trim_end_matches('/')))
        .unwrap_or(path);
    let mut list = String::new();
    for (product, quantity, unit, amount) in lignes {
        list.push_str(&format!(
            "<li><strong>{}</strong> — {:.2} {} — {:.2} €</li>",
            escape_html(product),
            quantity,
            escape_html(unit),
            amount
        ));
    }
    let content = format!(
        "<h1>Récapitulatif de votre commande n°{order_id}</h1><p>Bonjour {},</p><ul>{list}</ul><p><strong>Total : {total:.2} €</strong></p><h2>Modifier votre commande</h2><p>Utilisez le code <strong style=\"font-size:1.3em;letter-spacing:.12em\">{}</strong> jusqu’à la date limite de la vente.</p><p><a href=\"{}\">Consulter ou modifier ma commande</a></p><p>Après la date limite ou la clôture de la vente, le lien restera consultable mais les modifications seront bloquées.</p>",
        escape_html(nom_client),
        escape_html(code),
        escape_html(&link)
    );
    let subject = format!("Votre commande n°{order_id} — récapitulatif et code");
    let result = brevo_send(
        &settings,
        "email",
        destinataire,
        nom_client,
        &subject,
        &content,
    )
    .await;
    sqlx::query("INSERT INTO messageventedirecte(commande_id,client_id,canal,type_message,destinataire,contenu,succes,detail) VALUES(?,?,'email','recap_commande',?,?,?,?)")
        .bind(order_id)
        .bind(client_id)
        .bind(destinataire)
        .bind(&content)
        .bind(result.is_ok())
        .bind(match &result { Ok(value) | Err(value) => value })
        .execute(pool)
        .await?;
    match result {
        Ok(_) => {
            sqlx::query(
                "UPDATE commandeventedirecte SET recap_envoye_le=CURRENT_TIMESTAMP WHERE id=?",
            )
            .bind(order_id)
            .execute(pool)
            .await?;
            Ok(())
        }
        Err(error) => Err(AppError::Invalid(format!(
            "Échec de l’envoi du récapitulatif : {error}"
        ))),
    }
}

pub(super) async fn communications(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
) -> AppResult<Html<String>> {
    require_writer(&session)?;
    let settings=generic_rows(&state.pool,"SELECT id,CASE WHEN trim(COALESCE(brevo_api_key,''))<>'' THEN '••••••••' ELSE '' END AS api_configuree,sender_email,sender_name,sms_sender,email_list_id,sms_list_id FROM reglagecommunicationventedirecte WHERE id=1").await?;
    let clients=generic_rows(&state.pool,"SELECT id,nom,email,telephone,newsletter_email,newsletter_sms,cree_le FROM clientventedirecte ORDER BY nom").await?;
    let messages=generic_rows(&state.pool,"SELECT id,cree_le,canal,type_message,destinataire,succes,detail FROM messageventedirecte ORDER BY id DESC LIMIT 200").await?;
    let mut ctx = context(&session);
    ctx.insert(
        "reglages".into(),
        settings.into_iter().next().unwrap_or_else(|| json!({})),
    );
    ctx.insert("clients".into(), Value::Array(clients));
    ctx.insert("messages".into(), Value::Array(messages));
    render(
        &state,
        "vente_directe_communications.html",
        Value::Object(ctx),
    )
}

pub(super) async fn communications_reglages(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
    Form(form): Form<HashMap<String, String>>,
) -> AppResult<Response> {
    require_admin(&session)?;
    verify_csrf(&session, &form)?;
    let existing: Option<String> =
        sqlx::query_scalar("SELECT brevo_api_key FROM reglagecommunicationventedirecte WHERE id=1")
            .fetch_optional(&state.pool)
            .await?
            .flatten();
    let key = form_text(&form, "brevo_api_key").or(existing);
    sqlx::query("INSERT INTO reglagecommunicationventedirecte(id,brevo_api_key,sender_email,sender_name,sms_sender,email_list_id,sms_list_id) VALUES(1,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET brevo_api_key=excluded.brevo_api_key,sender_email=excluded.sender_email,sender_name=excluded.sender_name,sms_sender=excluded.sms_sender,email_list_id=excluded.email_list_id,sms_list_id=excluded.sms_list_id").bind(key).bind(form_text(&form,"sender_email")).bind(form_text(&form,"sender_name").unwrap_or_else(||"EI ORY EMMANUEL".into())).bind(form_text(&form,"sms_sender").unwrap_or_else(||"ORYEMMANUEL".into())).bind(form_i64(&form,"email_list_id")).bind(form_i64(&form,"sms_list_id")).execute(&state.pool).await?;
    Ok(Redirect::to("/vente-directe/communications").into_response())
}

async fn send_test(
    state: &AppState,
    session: &SessionData,
    form: &HashMap<String, String>,
    channel: &str,
) -> AppResult<Response> {
    require_admin(session)?;
    verify_csrf(session, form)?;
    let settings = comm_settings(&state.pool).await?;
    let to = form_text(form, "destinataire")
        .ok_or_else(|| AppError::Invalid("Destinataire obligatoire".into()))?;
    let content = form_text(form, "contenu").unwrap_or_else(|| "Test EO_Sevel".into());
    let subject = form_text(form, "sujet").unwrap_or_else(|| "Test EO_Sevel".into());
    let result = brevo_send(&settings, channel, &to, "Test", &subject, &content).await;
    log_message(&state.pool, None, channel, "test", &to, &content, &result).await?;
    if let Err(error) = result {
        return Err(AppError::Invalid(format!("Échec de l'envoi: {error}")));
    }
    Ok(Redirect::to("/vente-directe/communications?test=ok").into_response())
}
pub(super) async fn test_email(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
    Form(form): Form<HashMap<String, String>>,
) -> AppResult<Response> {
    send_test(&state, &session, &form, "email").await
}
pub(super) async fn test_sms(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
    Form(form): Form<HashMap<String, String>>,
) -> AppResult<Response> {
    send_test(&state, &session, &form, "sms").await
}

async fn newsletter(
    state: &AppState,
    session: &SessionData,
    form: &HashMap<String, String>,
    channel: &str,
) -> AppResult<Response> {
    require_admin(session)?;
    verify_csrf(session, form)?;
    let settings = comm_settings(&state.pool).await?;
    let subject = form_text(form, "sujet").unwrap_or_else(|| "Actualités de la ferme".into());
    let content = form_text(form, "contenu")
        .ok_or_else(|| AppError::Invalid("Message obligatoire".into()))?;
    let sql = if channel == "email" {
        "SELECT id,nom,email FROM clientventedirecte WHERE newsletter_email=1 AND trim(COALESCE(email,''))<>''"
    } else {
        "SELECT id,nom,telephone FROM clientventedirecte WHERE newsletter_sms=1 AND trim(COALESCE(telephone,''))<>''"
    };
    let clients: Vec<(i64, String, Option<String>)> =
        sqlx::query_as(sql).fetch_all(&state.pool).await?;
    let mut sent = 0;
    for (id, name, to) in clients {
        let Some(to) = to else { continue };
        let result = brevo_send(&settings, channel, &to, &name, &subject, &content).await;
        log_message(
            &state.pool,
            Some(id),
            channel,
            "newsletter",
            &to,
            &content,
            &result,
        )
        .await?;
        if result.is_ok() {
            sent += 1;
        }
    }
    Ok(Redirect::to(&format!("/vente-directe/communications?envoyes={sent}")).into_response())
}
pub(super) async fn newsletter_email(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
    Form(form): Form<HashMap<String, String>>,
) -> AppResult<Response> {
    newsletter(&state, &session, &form, "email").await
}
pub(super) async fn newsletter_sms(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
    Form(form): Form<HashMap<String, String>>,
) -> AppResult<Response> {
    newsletter(&state, &session, &form, "sms").await
}

pub(super) async fn client_consentements(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
    Path(id): Path<i64>,
    Form(form): Form<HashMap<String, String>>,
) -> AppResult<Response> {
    require_writer(&session)?;
    verify_csrf(&session, &form)?;
    sqlx::query("UPDATE clientventedirecte SET newsletter_email=?,newsletter_sms=? WHERE id=?")
        .bind(form.contains_key("newsletter_email"))
        .bind(form.contains_key("newsletter_sms"))
        .bind(id)
        .execute(&state.pool)
        .await?;
    Ok(Redirect::to("/vente-directe/communications").into_response())
}

pub(super) async fn desinscription(
    State(state): State<AppState>,
    Path(token): Path<String>,
) -> AppResult<Html<String>> {
    if token.trim().is_empty() {
        return Err(AppError::NotFound);
    }
    let result=sqlx::query("UPDATE clientventedirecte SET newsletter_email=0,newsletter_sms=0 WHERE token_desinscription=? AND token_desinscription<>''").bind(token).execute(&state.pool).await?;
    if result.rows_affected() == 0 {
        return Err(AppError::NotFound);
    }
    Ok(Html("<!doctype html><meta charset='utf-8'><main><h1>Désinscription confirmée</h1><p>Vous ne recevrez plus les communications commerciales.</p></main>".into()))
}

pub(super) async fn recalculer_stocks(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
    Form(form): Form<HashMap<String, String>>,
) -> AppResult<Response> {
    require_writer(&session)?;
    verify_csrf(&session, &form)?;
    db::journal(
        &state.pool,
        &session.nom,
        "verifier",
        "stocks_vente_directe",
        "Aucune double déduction: les inventaires restent la référence",
        "/vente-directe/recalculer-stocks",
    )
    .await;
    Ok(Redirect::to("/vente-directe?stocks=verifies").into_response())
}

pub(super) async fn vente_session_detail(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
    Path(id): Path<i64>,
) -> AppResult<Html<String>> {
    require_writer(&session)?;
    let session_row=generic_rows(&state.pool,&format!("SELECT s.id,s.nom,s.date_creation,s.date_livraison,s.nb_porcs,s.bande_reference,s.active,s.notes,ROUND(COALESCE(SUM(CASE WHEN c.statut<>'annulee' THEN c.total ELSE 0 END),0),2) AS chiffre_affaires FROM sessionventedirecte s LEFT JOIN commandeventedirecte c ON c.session_vente_id=s.id WHERE s.id={id} GROUP BY s.id")).await?.into_iter().next().ok_or(AppError::NotFound)?;
    let commands=generic_rows(&state.pool,&format!("SELECT id,cree_le,nom_client,telephone,email,statut,total FROM commandeventedirecte WHERE session_vente_id={id} ORDER BY id DESC")).await?;
    let unattached=generic_rows(&state.pool,"SELECT id,cree_le,nom_client,total FROM commandeventedirecte WHERE session_vente_id IS NULL ORDER BY id DESC LIMIT 100").await?;
    let charges=generic_rows(&state.pool,&format!("SELECT id,categorie,libelle,montant,note FROM chargeventedirecte WHERE session_vente_id={id} ORDER BY id DESC")).await?;
    let mut ctx = context(&session);
    ctx.insert("vente_session".into(), session_row);
    ctx.insert("commandes".into(), Value::Array(commands));
    ctx.insert("sans_session".into(), Value::Array(unattached));
    ctx.insert("charges".into(), Value::Array(charges));
    render(&state, "vente_session_detail.html", Value::Object(ctx))
}

pub(super) async fn vente_session_commande_rattacher(
    State(state): State<AppState>,
    Extension(session): Extension<SessionData>,
    Path((id, command_id)): Path<(i64, i64)>,
    Form(form): Form<HashMap<String, String>>,
) -> AppResult<Response> {
    require_writer(&session)?;
    verify_csrf(&session, &form)?;
    let exists: i64 = sqlx::query_scalar("SELECT COUNT(*) FROM sessionventedirecte WHERE id=?")
        .bind(id)
        .fetch_one(&state.pool)
        .await?;
    if exists == 0 {
        return Err(AppError::NotFound);
    }
    sqlx::query("UPDATE commandeventedirecte SET session_vente_id=? WHERE id=?")
        .bind(id)
        .bind(command_id)
        .execute(&state.pool)
        .await?;
    Ok(Redirect::to(&format!("/vente-directe/session/{id}")).into_response())
}

#[cfg(test)]
mod perte_porcelet_tests {
    use super::*;
    use crate::config::Config;
    use minijinja::Environment;
    use sqlx::sqlite::SqlitePoolOptions;

    async fn test_state() -> AppResult<(AppState, i64, i64)> {
        let pool = SqlitePoolOptions::new()
            .max_connections(1)
            .connect("sqlite::memory:")
            .await?;
        sqlx::raw_sql(include_str!("../../migrations/0001_schema.sql"))
            .execute(&pool)
            .await?;
        sqlx::raw_sql(include_str!(
            "../../migrations/0012_observation_comportement.sql"
        ))
        .execute(&pool)
        .await?;
        let site = sqlx::query("INSERT INTO site(code,nom) VALUES('S1','Site test')")
            .execute(&pool)
            .await?
            .last_insert_rowid();
        let room = sqlx::query(
            "INSERT INTO salle(site_id,nom,type,nb_cases,ordre) VALUES(?,'Maternité 1','Maternité',1,1)",
        )
        .bind(site)
        .execute(&pool)
        .await?
        .last_insert_rowid();
        let pen = sqlx::query("INSERT INTO casesalle(salle_id,nom) VALUES(?,'Case 1')")
            .bind(room)
            .execute(&pool)
            .await?
            .last_insert_rowid();
        let band =
            sqlx::query("INSERT INTO bande(code,date_mb,active) VALUES('BTEST','2026-08-01',1)")
                .execute(&pool)
                .await?
                .last_insert_rowid();
        let sow = sqlx::query(
            "INSERT INTO truie(num_travail,bande_code,statut,reformee) VALUES('T1','BTEST','active',0)",
        )
        .execute(&pool)
        .await?
        .last_insert_rowid();
        sqlx::query("INSERT INTO evenement(type,date,truie_id,bande_id,nes_vifs) VALUES('mise_bas','2026-08-01',?,?,10)")
            .bind(sow).bind(band).execute(&pool).await?;
        sqlx::query("INSERT OR IGNORE INTO causeperte(libelle) VALUES('Autre')")
            .execute(&pool)
            .await?;

        let config = Config {
            bind: "0.0.0.0:8080".parse().unwrap(),
            db_path: std::path::PathBuf::from("data/test.db"),
            secure_cookies: false,
        };
        let env = Environment::new();
        let state = AppState::new(config, pool, env);
        Ok((state, sow, pen))
    }

    fn session() -> SessionData {
        SessionData {
            uid: 1,
            identifiant: "test".into(),
            nom: "Test".into(),
            role: "admin".into(),
            sections: vec![],
            csrf: "csrf-test".into(),
            doit_changer_mdp: false,
            type_elevage: "naisseur_engraisseur".into(),
            module_genetique: false,
            module_prestataires: true,
            module_charcutiers_rfid: false,
            module_vente_directe: true,
        }
    }

    fn perte_form(sow: i64, pen: i64, nombre: &str) -> HashMap<String, String> {
        [
            ("csrf_token", "csrf-test"),
            ("type", "perte"),
            ("truie_id", &sow.to_string()),
            ("case_id", &pen.to_string()),
            ("cause", "Autre"),
            ("nombre", nombre),
            ("date", "2026-08-10"),
        ]
        .into_iter()
        .map(|(a, b)| (a.to_string(), b.to_string()))
        .collect()
    }

    /// Vrai bug corrigé : une case de maternité choisie comme « case
    /// d'origine » de la perte rejetait systématiquement la saisie avec
    /// « Effectif insuffisant dans la case : 0 porc(s) présent(s) », car le
    /// contrôle lisait `inventairecase`/`transfert` — jamais renseignés pour
    /// des porcelets sous la mère — au lieu du nombre né vivant moins les
    /// pertes déjà déclarées. Une perte plausible (inférieure aux 10 nés
    /// vifs) doit désormais être acceptée.
    #[tokio::test]
    async fn perte_porcelet_sous_la_mere_est_acceptee_avec_une_case_maternite() -> anyhow::Result<()>
    {
        let (state, sow, pen) = test_state().await?;
        saisie_rapide(
            State(state.clone()),
            Extension(session()),
            Form(perte_form(sow, pen, "3")),
        )
        .await?;
        let recorded: i64 = sqlx::query_scalar("SELECT COALESCE(SUM(nb),0) FROM perteporcelet")
            .fetch_one(&state.pool)
            .await?;
        assert_eq!(recorded, 3);
        Ok(())
    }

    /// Une perte au-delà des porcelets réellement nés vivants doit toujours
    /// être refusée, avec un message qui reflète le vrai effectif de la
    /// portée plutôt qu'un compte de case toujours nul.
    #[tokio::test]
    async fn perte_porcelet_au_dela_de_la_portee_est_refusee() -> anyhow::Result<()> {
        let (state, sow, pen) = test_state().await?;
        let err = saisie_rapide(
            State(state),
            Extension(session()),
            Form(perte_form(sow, pen, "999")),
        )
        .await
        .expect_err("doit être refusée");
        match err {
            AppError::Invalid(message) => {
                assert!(message.contains("sous la mère"), "message: {message}");
                assert!(message.contains("10 porcelet"), "message: {message}");
            }
            other => panic!("erreur inattendue: {other:?}"),
        }
        Ok(())
    }

    /// Vrai bug corrigé ici : sur les bases héritées de la 1.65,
    /// `declarationmort.horodatage` est NOT NULL sans valeur par défaut.
    /// `CREATE TABLE IF NOT EXISTS` ne redéfinit pas une table existante, si
    /// bien que le schéma neuf et la base d'un élevage en production ne se
    /// ressemblent pas sur ce point. L'INSERT qui s'en remettait au DEFAULT
    /// passait donc tous les tests et échouait chez l'éleveur, avec une page
    /// d'erreur générique renvoyant au journal.
    #[tokio::test]
    async fn perte_porcelet_sur_une_base_heritee_sans_defaut_horodatage() -> anyhow::Result<()> {
        let (state, sow, pen) = test_state().await?;
        // La table telle que la version Python la créait.
        sqlx::raw_sql(
            "DROP TABLE declarationmort;
             CREATE TABLE declarationmort (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                horodatage TEXT NOT NULL,
                bande_code TEXT, date TEXT, stade TEXT,
                case_id INTEGER REFERENCES casesalle(id),
                cause TEXT, poids REAL,
                nombre INTEGER NOT NULL DEFAULT 1,
                declare_par TEXT, note TEXT);",
        )
        .execute(&state.pool)
        .await?;
        saisie_rapide(
            State(state.clone()),
            Extension(session()),
            Form(perte_form(sow, pen, "2")),
        )
        .await?;
        let (nombre, horodatage): (i64, String) =
            sqlx::query_as("SELECT nombre,horodatage FROM declarationmort")
                .fetch_one(&state.pool)
                .await?;
        assert_eq!(nombre, 2);
        assert!(!horodatage.trim().is_empty(), "horodatage renseigné");
        let pertes: i64 = sqlx::query_scalar("SELECT COALESCE(SUM(nb),0) FROM perteporcelet")
            .fetch_one(&state.pool)
            .await?;
        assert_eq!(pertes, 2);
        Ok(())
    }

    /// L'âge n'est plus demandé à la saisie : il doit se calculer seul,
    /// sinon plus moyen d'étudier ensuite à quel moment de la lactation les
    /// pertes surviennent.
    #[tokio::test]
    async fn l_age_de_la_perte_se_calcule_sans_etre_saisi() -> anyhow::Result<()> {
        let (state, sow, pen) = test_state().await?;
        let mut form = perte_form(sow, pen, "1");
        form.insert("date".into(), "2026-08-06".into());
        // Le formulaire n'envoie plus d'âge : la valeur doit venir du calcul.
        assert!(!form.contains_key("age_j"));
        saisie_rapide(State(state.clone()), Extension(session()), Form(form)).await?;
        // Mise-bas au 1er août, perte au 6 : cinq jours.
        let age: Option<i64> =
            sqlx::query_scalar("SELECT age_j FROM perteporcelet ORDER BY id DESC LIMIT 1")
                .fetch_one(&state.pool)
                .await?;
        assert_eq!(age, Some(5));
        Ok(())
    }

    /// Les porcelets aux pattes écartées sont vivants : les compter comme une
    /// perte fausserait les nés vifs de la portée. Le nombre est conservé sur
    /// la truie, où il sert de critère de sélection des mères à cochettes.
    #[tokio::test]
    async fn le_splayleg_est_note_sans_toucher_aux_nes_vifs() -> anyhow::Result<()> {
        let (state, sow, _pen) = test_state().await?;
        let form: HashMap<String, String> = [
            ("csrf_token", "csrf-test"),
            ("type", "mise_bas"),
            ("date", "2026-08-20"),
            ("truie_id", &sow.to_string()),
            ("nes_vifs", "14"),
            ("mort_nes", "1"),
            ("momifies", "0"),
            ("splayleg", "2"),
            ("delivrance_ok", "1"),
        ]
        .into_iter()
        .map(|(a, b)| (a.to_string(), b.to_string()))
        .collect();
        saisie_rapide(State(state.clone()), Extension(session()), Form(form)).await?;

        let (vifs, delivrance): (i64, Option<i64>) = sqlx::query_as(
            "SELECT nes_vifs,delivrance_ok FROM evenement WHERE type='mise_bas' AND date='2026-08-20'",
        )
        .fetch_one(&state.pool)
        .await?;
        assert_eq!(vifs, 14, "les splayleg restent dans les nés vifs");
        assert_eq!(delivrance, Some(1));
        let splayleg: Option<i64> = sqlx::query_scalar("SELECT splayleg FROM truie WHERE id=?")
            .bind(sow)
            .fetch_one(&state.pool)
            .await?;
        assert_eq!(splayleg, Some(2));
        // Aucune perte ne doit avoir été créée pour ces porcelets.
        let pertes: i64 = sqlx::query_scalar(
            "SELECT COALESCE(SUM(nb),0) FROM perteporcelet WHERE lower(COALESCE(cause,'')) LIKE '%splay%'",
        )
        .fetch_one(&state.pool)
        .await?;
        assert_eq!(pertes, 0);
        Ok(())
    }

    /// Une cochette arrive avec tout ce qui servira à juger sa carrière :
    /// filiation, naissance, poids d'entrée. Ces informations ne se
    /// retrouvent plus après coup, elles doivent être saisies à l'arrivée.
    #[tokio::test]
    async fn une_cochette_entre_au_cheptel_avec_sa_filiation() -> anyhow::Result<()> {
        let (state, _sow, _pen) = test_state().await?;
        let champs = |numero: &str| -> HashMap<String, String> {
            [
                ("csrf_token", "csrf-test"),
                ("type", "cochette"),
                ("date", "2026-08-20"),
                ("num_travail", numero),
                ("num_national", "FR35123456"),
                ("rfid", "982000123456789"),
                ("date_naissance", "2026-02-14"),
                ("poids", "132,5"),
                ("race", "Landrace"),
                ("pere_national", "P-900"),
                ("mere_national", "M-450"),
                ("bande_code", "BTEST"),
            ]
            .into_iter()
            .map(|(a, b)| (a.to_string(), b.to_string()))
            .collect()
        };
        saisie_rapide(
            State(state.clone()),
            Extension(session()),
            Form(champs("900001")),
        )
        .await?;

        // Une colonne par ligne : la fiche vaut par le fait qu'aucune de ces
        // informations ne se retrouve après coup.
        for (colonne, attendu) in [
            ("num_national", "FR35123456"),
            ("rfid", "982000123456789"),
            ("date_naissance", "2026-02-14"),
            ("race", "Landrace"),
            ("pere_national", "P-900"),
            ("mere_national", "M-450"),
            ("bande_code", "BTEST"),
        ] {
            let valeur: Option<String> = sqlx::query_scalar(&format!(
                "SELECT {colonne} FROM truie WHERE num_travail='900001'"
            ))
            .fetch_one(&state.pool)
            .await?;
            assert_eq!(valeur.as_deref(), Some(attendu), "colonne {colonne}");
        }

        // Le poids d'entrée rejoint les mesures, décimale française comprise.
        let poids: Option<f64> = sqlx::query_scalar(
            "SELECT poids FROM mesuretruie WHERE truie_id=(SELECT id FROM truie WHERE num_travail='900001')",
        )
        .fetch_one(&state.pool)
        .await?;
        assert_eq!(poids, Some(132.5));

        // Un numéro déjà porté doit être refusé : deux truies homonymes au
        // cheptel rendraient toute analyse de carrière ininterprétable.
        let err = saisie_rapide(
            State(state.clone()),
            Extension(session()),
            Form(champs("900001")),
        )
        .await
        .expect_err("doublon refusé");
        assert!(matches!(err, AppError::Invalid(ref m) if m.contains("900001")));
        Ok(())
    }

    fn comportement_form(band_id: i64, pen: i64) -> HashMap<String, String> {
        [
            ("csrf_token", "csrf-test"),
            ("type", "comportement"),
            ("date", "2026-08-12"),
            ("bande_id", &band_id.to_string()),
            ("case_id", &pen.to_string()),
            ("categorie", "queue_mordue"),
            ("gravite", "aggravation"),
            ("nombre", "3"),
            ("note", "surveillé de près"),
        ]
        .into_iter()
        .map(|(a, b)| (a.to_string(), b.to_string()))
        .collect()
    }

    /// La salle se déduit de la case saisie : ne pas la redemander, sinon
    /// deux versions de la même information peuvent se contredire.
    #[tokio::test]
    async fn observation_comportementale_deduit_la_salle_de_la_case() -> anyhow::Result<()> {
        let (state, _sow, pen) = test_state().await?;
        let band_id: i64 = sqlx::query_scalar("SELECT id FROM bande WHERE code='BTEST'")
            .fetch_one(&state.pool)
            .await?;
        saisie_rapide(
            State(state.clone()),
            Extension(session()),
            Form(comportement_form(band_id, pen)),
        )
        .await?;
        let (categorie, gravite, nombre, salle_id): (String, String, Option<i64>, Option<i64>) =
            sqlx::query_as(
                "SELECT categorie,gravite,nombre,salle_id FROM observation_comportement",
            )
            .fetch_one(&state.pool)
            .await?;
        assert_eq!(categorie, "queue_mordue");
        assert_eq!(gravite, "aggravation");
        assert_eq!(nombre, Some(3));
        assert!(salle_id.is_some(), "la salle doit se déduire de la case");
        Ok(())
    }

    /// Une catégorie ou une gravité hors du vocabulaire fermé doit être
    /// refusée : c'est ce qui permet ensuite de les compter sans distinguer
    /// des variantes d'orthographe.
    #[tokio::test]
    async fn observation_comportementale_refuse_une_categorie_inconnue() -> anyhow::Result<()> {
        let (state, _sow, pen) = test_state().await?;
        let band_id: i64 = sqlx::query_scalar("SELECT id FROM bande WHERE code='BTEST'")
            .fetch_one(&state.pool)
            .await?;
        let mut form = comportement_form(band_id, pen);
        form.insert("categorie".into(), "morsure_de_queue".into());
        let err = saisie_rapide(State(state.clone()), Extension(session()), Form(form))
            .await
            .expect_err("catégorie inconnue refusée");
        assert!(matches!(err, AppError::Invalid(_)));

        let mut form = comportement_form(band_id, pen);
        form.insert("gravite".into(), "grave".into());
        let err = saisie_rapide(State(state), Extension(session()), Form(form))
            .await
            .expect_err("gravité inconnue refusée");
        assert!(matches!(err, AppError::Invalid(_)));
        Ok(())
    }
}
